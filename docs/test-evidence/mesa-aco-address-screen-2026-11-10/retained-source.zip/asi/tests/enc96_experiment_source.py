# SPDX-License-Identifier: MIT
"""Keep isolated experiments rooted at the accepted pre-optimization checkpoint."""
from pathlib import Path
import os,subprocess,shutil
def baseline_shader(root,source=None):
 name='enc_stage_96_128_128.comp'
 reference=Path(root)/'reference';reference.mkdir(parents=True,exist_ok=True)
 repository=Path(__file__).resolve().parents[2]
 git_marker=repository/'.git'
 command=['git']
 if os.name!='nt' and git_marker.is_file():
  # Windows-created worktrees store a drive-letter gitdir; Linux Git treats
  # it as relative unless it is translated explicitly for WSL.
  gitdir=git_marker.read_text().strip().removeprefix('gitdir: ').strip()
  if len(gitdir)>2 and gitdir[1]==':':
   gitdir=subprocess.check_output(['wslpath','-u',gitdir],text=True).strip()
  else:
   gitdir=str((repository/gitdir).resolve())
  command+=['--git-dir='+gitdir]
 # Includes may also acquire a retained optimization. Reset the one changed
 # in this stage so every prior experiment still starts at the same source.
 for relative in (name,'include/onr_block_fast.glsl','include/onr_block.glsl','include/onr_block_w2.glsl','dec_dfn_96_128.comp'):
  data=subprocess.check_output(command+['show','ba817e3:gpu/shaders/'+relative],cwd=repository)
  dest=reference/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
  if source is not None:shutil.copy2(dest,Path(source)/relative)
 return reference/name

def before_address_source(source):
 """Copy current retained enc96, excluding the later FC1 address factor."""
 source=Path(source)
 shutil.copytree('gpu/shaders',source,dirs_exist_ok=True)
 repository=Path(__file__).resolve().parents[2]
 gitdir=(repository/'.git').read_text().strip().removeprefix('gitdir: ').strip()
 if os.name!='nt' and len(gitdir)>2 and gitdir[1]==':':
  gitdir=subprocess.check_output(['wslpath','-u',gitdir],text=True).strip()
 for relative in ('include/onr_block.glsl','include/onr_block_w2.glsl','dec_dfn_96_128.comp'):
  data=subprocess.check_output(['git','--git-dir='+gitdir,'show','ba817e3:gpu/shaders/'+relative],cwd=repository)
  (source/relative).write_bytes(data)
 return source

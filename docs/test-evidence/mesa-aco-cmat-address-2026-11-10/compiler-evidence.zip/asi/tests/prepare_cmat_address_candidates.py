# SPDX-License-Identifier: MIT
"""Isolate bounded lane-address record variants atop current retained control."""
from pathlib import Path
import json,os,shutil,subprocess,sys,hashlib
sys.path.insert(0,'asi/build')
from build_aco_records import fnv,msgpack
root=Path('build/aco-runtime-trace/experiment-cmat-address')
baseline=Path('build/aco-runtime-trace/experiment-address-screen/dec_dfn_96_128/candidate')
isolated=root/'isolated-toolchain.json'
cfg=json.loads((isolated if isolated.exists() else Path('build/aco-tools/toolchain.json')).read_text())
lib=root/'compiler/libvulkan_radeon.so' if isolated.exists() else Path('/home/kenny/work/openrr-mesa-aco/build/src/amd/vulkan/libvulkan_radeon.so')
cfg.update(radv_sha256=hashlib.sha256(lib.read_bytes()).hexdigest(),cmat_address='bounded-lane-byte-offset-v1',cmat_address_patch_sha256=hashlib.sha256(Path('asi/build/mesa/global-address.patch').read_bytes()).hexdigest())
config=root/'toolchain.json';config.write_text(json.dumps(cfg,indent=2)+chr(10))
for name in ('enc_stage_96_128_128_fl_lt','dec_dfn_96_128_fl_lt'):
 dest=root/name/'candidate';data=dest/'data/shaders';shutil.copytree(baseline/'data/shaders',data,dirs_exist_ok=True)
 env=dict(os.environ,ONR_ACO_CMAT_ADDRESS='1')
 subprocess.run([sys.executable,'asi/build/build_aco_records.py',str(data/(name+'.spv')),'--out',str(dest/'records'),'--toolchain',str(config),'--precision','global','--matrix-loads','vector8'],check=True,env=env)
 records=dest/'records/gfx1201/openrr-d3d12-v1';m=json.loads((records/'manifest.json').read_text());key=f'{fnv((data/(name+".spv")).read_bytes()):016x}'
 original=json.loads((baseline/'records/gfx1201/openrr-d3d12-v1/manifest.json').read_text())
 for p in (baseline/'records/gfx1201/openrr-d3d12-v1').glob('*.nrp'):
  if p.stem!=key:shutil.copy2(p,records/p.name)
 original['records'].update(m['records']);original['experiment']=dict(name='cmat-bounded-lane-address',target=name,toolchain=cfg)
 manifest=records/'manifest.json';manifest.write_text(json.dumps(original,indent=2)+chr(10))
 index={k:original[k] for k in ('schema','target','layout_version','wave_size','layout_push_bytes','mesa_commit','patch_version')}
 index['manifest_hash']=fnv(manifest.read_bytes());index['records']={k:{f:r[f] for f in ('spv_hash','code_hash','workgroup','layout','record')} for k,r in original['records'].items()}
 (records/'manifest.msgpack').write_bytes(msgpack(index))
 print(name,key,original['records'][key]['code_hash'])

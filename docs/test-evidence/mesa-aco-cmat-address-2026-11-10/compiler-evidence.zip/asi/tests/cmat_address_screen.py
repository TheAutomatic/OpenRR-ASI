# SPDX-License-Identifier: MIT
"""Compile-only paired cmat lane-address screen, identical current SPIR-V."""
from pathlib import Path
import json,os,sys,subprocess,hashlib,re,zipfile
from collections import Counter
sys.path.insert(0,'asi/build')
from build_aco_records import fnv
root=Path('build/aco-runtime-trace/experiment-cmat-address');root.mkdir(exist_ok=True)
out=Path('docs/test-evidence/mesa-aco-cmat-address-2026-11-10');out.mkdir(exist_ok=True)
config=root/'isolated-toolchain.json'
cfg=json.loads((config if config.exists() else Path('build/aco-tools/toolchain.json')).read_text())
base=Path('build/aco-runtime-trace/experiment-address-screen/dec_dfn_96_128/candidate/data/shaders')
rows=[]
for name in ('enc_stage_128_128_160_fl_lt','enc_stage_96_128_128_fl_lt','dec_dfn_96_128_fl_lt'):
 spv=base/(name+'.spv');row={'shader':name,'spv_fnv':f'{fnv(spv.read_bytes()):016x}','spv_sha256':hashlib.sha256(spv.read_bytes()).hexdigest()}
 for role in ('off','on'):
  dest=root/name/role;dest.mkdir(parents=True,exist_ok=True)
  env=dict(os.environ,VK_ICD_FILENAMES=cfg['icd'],LD_PRELOAD=cfg['shim'],AMDGPU_GPU_ID='gfx1201',MESA_SHADER_CACHE_DISABLE='true',LD_LIBRARY_PATH=cfg['library_path'],ONR_ACO_PRECISION='global',ONR_ACO_VECTOR_LOADS='1',ONR_ACO_CAPTURE=str((dest/'capture').resolve()),ONR_ACO_ADDR32_HI='0x13579bdf',ONR_ISA=str(dest.resolve()))
  env.pop('ONR_ACO_CMAT_ADDRESS',None)
  if role=='on':env['ONR_ACO_CMAT_ADDRESS']='1'
  r=subprocess.run([str(Path('build/aco-tools/aco_capture').resolve()),str(spv.resolve())],env=env,text=True,capture_output=True)
  (dest/'compile.log').write_text(r.stdout+r.stderr);r.check_returncode()
  ir=next(dest.glob('*.2.txt')).read_text().split('After lowering to hw instructions:',1)[1]
  ops=Counter()
  for line in ir.splitlines():
   m=re.search(r'([sv]_[a-z0-9_]+|ds_[a-z0-9_]+|global_[a-z0-9_]+|scratch_[a-z0-9_]+)',line)
   if m:ops[m[1]]+=1
  row[role]={'resources':json.loads((dest/'capture.json').read_text()),'opcodes':dict(sorted(ops.items())),'code_sha256':hashlib.sha256((dest/'capture.code').read_bytes()).hexdigest()}
 rows.append(row)
(out/'screen.json').write_text(json.dumps(rows,indent=2)+chr(10))
with zipfile.ZipFile(out/'compiler-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in root.rglob('*'):
  if p.is_file():z.write(p,p.relative_to(root))
 z.write('asi/build/mesa/global-address.patch','global-address.patch')
for r in rows:
 print(r['shader'],r['spv_fnv'])
 for role in ('off','on'):
  a=r[role];print(role,a['resources'],{k:v for k,v in a['opcodes'].items() if any(s in k for s in ('add','lsh','wait','global_load'))})

# SPDX-License-Identifier: MIT
"""Temporary compile diagnostics only; no change to unroll decisions."""
from pathlib import Path
import shutil,subprocess
work=Path('/home/kenny/work/openrr-mesa-aco')
out=Path('build/aco-runtime-trace/experiment-enc128-unroll');out.mkdir(exist_ok=True)
p=work/'source/src/compiler/nir/nir_opt_loop_unroll.c'
backup=out/'nir_opt_loop_unroll.original.c'
if not backup.exists():shutil.copy2(p,backup)
old=backup.read_text()
anchor='''   unsigned cost = li->instr_cost * trip_count;
'''
assert old.count(anchor)==1
new=old.replace(anchor,anchor+'''
   if (getenv("ONR_UNROLL_PROBE") && trip_count >= 8) {
      fprintf(stderr, "ONR_UNROLL trip=%u body_cost=%u cost=%u limit=%u pipeline=%u flatten=%u control=%u force=%u exact=%u accept=%u\\n",
              trip_count, li->instr_cost, cost, cost_limit, can_pipeline_loads(loop),
              li->flattens_all_control_flow, loop->control, li->force_unroll,
              li->exact_trip_count_known, cost <= cost_limit && trip_count <= max_iter);
      nir_foreach_instr(instr, nir_loop_first_block(loop)) nir_print_instr(instr, stderr);
   }
''')
anchor='   if (li->force_unroll && !li->guessed_trip_count && trip_count <= max_iter)'
new=new.replace(anchor,'''   if (getenv("ONR_UNROLL_PROBE") && trip_count >= 8)
      fprintf(stderr, "ONR_PRE trip=%u body=%u max=%u force=%u guessed=%u pipeline=%u flatten=%u\\n",
              trip_count, li->instr_cost, max_iter, li->force_unroll,
              li->guessed_trip_count, can_pipeline_loads(loop), li->flattens_all_control_flow);
''' + anchor)
p.write_text(new)
shutil.copy2('build/aco-runtime-trace/experiment-cmat-address/compiler/radv_nir_lower_cooperative_matrix.c',work/'source/src/amd/vulkan/nir/radv_nir_lower_cooperative_matrix.c')
subprocess.run(['ninja','-C',str(work/'build'),'-j','8'],check=True)

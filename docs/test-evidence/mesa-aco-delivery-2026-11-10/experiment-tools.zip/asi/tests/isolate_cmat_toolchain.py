# SPDX-License-Identifier: MIT
"""Keep opt-in compiler separate and restore default capture library/source."""
from pathlib import Path
import json,shutil,hashlib
work=Path('/home/kenny/work/openrr-mesa-aco')
root=Path('build/aco-runtime-trace/experiment-cmat-address')
backup=Path('build/aco-tools/global-address-baseline')
dest=root/'compiler';dest.mkdir(exist_ok=True)
lib=work/'build/src/amd/vulkan/libvulkan_radeon.so'
shutil.copy2(lib,dest/lib.name)
icd=json.loads((work/'build/src/amd/vulkan/radeon_devenv_icd.x86_64.json').read_text())
icd['ICD']['library_path']=str((dest/lib.name).resolve())
path=dest/'icd.json';path.write_text(json.dumps(icd,indent=2)+chr(10))
cfg=json.loads((root/'toolchain.json').read_text());cfg['icd']=str(path.resolve())
(root/'isolated-toolchain.json').write_text(json.dumps(cfg,indent=2)+chr(10))
shutil.copy2(work/'source/src/amd/vulkan/nir/radv_nir_lower_cooperative_matrix.c',dest/'radv_nir_lower_cooperative_matrix.c')
shutil.copy2(backup/lib.name,lib)
shutil.copy2(backup/'radv_nir_lower_cooperative_matrix.c',work/'source/src/amd/vulkan/nir/radv_nir_lower_cooperative_matrix.c')
expected=json.loads(Path('build/aco-tools/toolchain.json').read_text())['radv_sha256']
assert hashlib.sha256(lib.read_bytes()).hexdigest()==expected
print('Isolated candidate compiler; default library and cmat source restored to capturev4')

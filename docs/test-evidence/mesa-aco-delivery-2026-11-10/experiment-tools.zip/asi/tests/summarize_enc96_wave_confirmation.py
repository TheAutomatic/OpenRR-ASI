# SPDX-License-Identifier: MIT
from pathlib import Path
import json,statistics,shutil,re,csv
root=Path('build/aco-runtime-trace/runs-approved-2026-11-10');out=Path('docs/test-evidence/mesa-aco-enc96-wave-tiles-experiment-2026-11-10')
rows=[]
for p in sorted((root/'enc96-wave-tiles-confirm').glob('round-*')):
 s=json.loads((p/'summary.json').read_text());o=json.loads((p/'order.json').read_text(encoding='utf-8-sig'));assert s['parity_passed']
 row={'round':o['round'],'first':o['baseline_role']}
 for label in ('baseline','candidate'):
  for phase in ('steady','drs'):row[o[label+'_role']+'_'+phase+'_ms']=s[label][phase+'_median_ms']
 rows.append(row);dest=out/('confirm-'+p.name);dest.mkdir(exist_ok=True)
 for name in ('summary.json','order.json','baseline-frame-state.csv','candidate-frame-state.csv'):shutil.copy2(p/name,dest/name)
stats={}
for phase in ('steady','drs'):
 d={}
 for role in ('original','variant'):
  v=[r[role+'_'+phase+'_ms'] for r in rows];d[role]={'median_ms':statistics.median(v),'min_ms':min(v),'max_ms':max(v)}
 d['change_percent']=100*(d['variant']['median_ms']/d['original']['median_ms']-1)
 d['paired_change_percent']=[100*(r['variant_'+phase+'_ms']/r['original_'+phase+'_ms']-1) for r in rows];stats[phase]=d
(out/'confirmation.json').write_text(json.dumps({'rounds':rows,'statistics':stats},indent=2)+'\n')
print(json.dumps(stats,indent=2))
profiles=[]
for p in sorted((root/'enc96-wave-tiles-profile').glob('round-*')):
 o=json.loads((p/'order.json').read_text(encoding='utf-8-sig'))
 for label in ('baseline','candidate'):
  text=(p/f'openrr_{label}.log').read_text()
  samples=re.findall(r'timestamp intervals, mean of (\d+) \(ms\):([^\n]+)\n[^\n]*stamped dispatches:([^\n]+)',text)
  count,values,names=max(samples,key=lambda x:int(x[0]));v=[float(x) for x in values.split()]
  index=int(next(t for t in names.split() if t.startswith('enc_stage_96_128_128_fl_lt.spv@')).split('@')[1])
  profiles.append({'round':o['round'],'role':o[label+'_role'],'samples':int(count),'target_ms':v[index]})
 dest=out/('profile-'+p.name);dest.mkdir(exist_ok=True)
 for name in ('summary.json','order.json','openrr_baseline.log','openrr_candidate.log'):shutil.copy2(p/name,dest/name)
(out/'profile.json').write_text(json.dumps(profiles,indent=2)+'\n');print(json.dumps(profiles,indent=2))

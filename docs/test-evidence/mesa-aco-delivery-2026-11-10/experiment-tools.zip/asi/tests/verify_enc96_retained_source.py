# SPDX-License-Identifier: MIT
"""Verify retained source reproduces tested candidate and leaves other variants intact."""
from pathlib import Path
import sys,subprocess,json,hashlib
sys.path.insert(0,'asi/build')
from build_shaders import parse_fastmode
root=Path('build/aco-runtime-trace/experiment-enc96-wave-tiles/source-verification');root.mkdir(exist_ok=True)
name='enc_stage_96_128_128';lt=parse_fastmode('gpu/fastmode.cmake')[name]
variants={'_f':['ENC_F32=1'],'_fl':['ENC_F32=1','FLOW=1','FLOW_SLOT=0','FLOW_WAIT=0'],'_f_lt':['ENC_F32=1']+lt,'_fl_lt':['ENC_F32=1','FLOW=1','FLOW_SLOT=0','FLOW_WAIT=0']+lt}
rows=[]
for suffix,defs in variants.items():
 file=name+suffix+'.spv';out=root/file
 subprocess.run(['glslangValidator','-V','--target-env','vulkan1.3',*[f'-D{d}' for d in defs],'-Igpu/shaders/include',f'gpu/shaders/{name}.comp','-o',str(out)],check=True)
 expected=Path('build/aco-runtime-trace/experiment-enc96-wave-rcp/data/shaders' if suffix=='_fl_lt' else 'build/asi/stage/openrr-amd/shaders')/file
 assert out.read_bytes()==expected.read_bytes(),file
 rows.append({'shader':file,'matches':'tested candidate' if suffix=='_fl_lt' else 'unchanged baseline','sha256':hashlib.sha256(out.read_bytes()).hexdigest()})
dest=Path('docs/test-evidence/mesa-aco-enc96-wave-tiles-experiment-2026-11-10/source-verification.json')
dest.write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))

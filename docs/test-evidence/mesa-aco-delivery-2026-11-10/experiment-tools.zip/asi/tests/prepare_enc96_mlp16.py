# SPDX-License-Identifier: MIT
"""Single factor: MLP hidden slice 32 -> 16, retaining each MMA chain order."""
from pathlib import Path
import shutil,subprocess,sys,json,difflib
sys.path.insert(0,'asi/build')
from build_shaders import parse_shader_lists,parse_fastmode
from build_aco_records import fnv
from enc96_experiment_source import baseline_shader
root=Path('build/aco-runtime-trace/experiment-enc96-mlp16');source=root/'source'
shutil.copytree('gpu/shaders',source,dirs_exist_ok=True)
baseline_shader(root,source)
p=source/'include/onr_block_w2.glsl';s=p.read_text()
start=s.index('    // 32-neuron slices: hidden tiles')
end=s.index('\n#endif\n    W2T(RES_A2)',start)
old=s[start:end]
new=r'''    // ACO experiment: one hidden channel tile at a time. FC1 K and FC2 K unchanged.
    for (uint j = 0u; j < LT_HID; j += 16u) {
        ACC hb0 = bias_acc_t(pc.fc1_b, j);
        ACC h00 = hb0, h10 = hb0;
#define FC1_K16(n) { MA f0; MB b_; \
            WLD(f0, pc.fc1.v, WT_FC1(j * ENC_C + uint(n) * 16u), WS_FC1, ROW); \
            CPB(b_, x0##n) MMA(h00, f0, b_) \
            CPB(b_, x1##n) MMA(h10, f0, b_) }
        W2T(FC1_K16)
        GELU1(h00) GELU1(h10)
        FC2_N(0u, h00, h10)
    }'''
p.write_text(s.replace(old,new))
name='enc_stage_96_128_128';flow=parse_shader_lists('gpu')[1];slot=flow.index(name)
defs=['ENC_F32=1','FLOW=1',f'FLOW_SLOT={slot}',f'FLOW_WAIT={int(slot>0)}']+parse_fastmode('gpu/fastmode.cmake')[name]
spvname=name+'_fl_lt.spv';base=root/'reference';base.mkdir(exist_ok=True)
data=root/'data/shaders';data.mkdir(parents=True,exist_ok=True)
for f in Path('build/asi/stage/openrr-amd/shaders').glob('*.spv'):shutil.copy2(f,data/f.name)
for inc,src,dst in [('gpu/shaders/include',base,base/spvname),(str(source/'include'),source,data/spvname)]:
 subprocess.run(['glslangValidator','-V','--target-env','vulkan1.3',*[f'-D{d}' for d in defs],f'-I{inc}',str(src/(name+'.comp')),'-o',str(dst)],check=True)
baseline=Path('build/asi/stage/openrr-amd/shaders')/spvname
assert (base/spvname).read_bytes()==baseline.read_bytes()
(root/'source-change.patch').write_text(''.join(difflib.unified_diff(s.splitlines(True),s.replace(old,new).splitlines(True),fromfile='original/onr_block_w2.glsl',tofile='mlp16/onr_block_w2.glsl')))
print(json.dumps({'baseline_spv':f'{fnv(baseline.read_bytes()):016x}','candidate_spv':f'{fnv((data/spvname).read_bytes()):016x}','defines':defs},indent=2))

# SPDX-License-Identifier: MIT
from pathlib import Path
import re,json,shutil
root=Path('build/aco-runtime-trace/runs-approved-2026-11-10/enc96-address-profile')
out=Path('docs/test-evidence/mesa-aco-enc96-address-experiment-2026-11-10')
rows=[]
for p in sorted(root.glob('round-*')):
 order=json.loads((p/'order.json').read_text(encoding='utf-8-sig'))
 for label in ('baseline','candidate'):
  text=(p/f'openrr_{label}.log').read_text()
  samples=re.findall(r'timestamp intervals, mean of (\d+) \(ms\):([^\n]+)\n[^\n]*stamped dispatches:([^\n]+)',text)
  count,values,names=max(samples,key=lambda x:int(x[0]));values=[float(v) for v in values.split()]
  target=next(t for t in names.split() if t.startswith('enc_stage_96_128_128_fl_lt.spv@'))
  index=int(target.split('@')[1]);rows.append({'round':order['round'],'role':order[label+'_role'],'samples':int(count),'target_ms':values[index]})
 dest=out/('profile-'+p.name);dest.mkdir(exist_ok=True)
 for name in ('summary.json','order.json','openrr_baseline.log','openrr_candidate.log'):shutil.copy2(p/name,dest/name)
(out/'profile.json').write_text(json.dumps(rows,indent=2)+'\n')
# Compact original post-spill evidence, keeping original line numbers.
src=Path('build/aco-runtime-trace/experiment-enc96/ir/original/enc_stage_96_128_128_fl_lt.1.txt').read_text().splitlines()
indices=set()
for i,line in enumerate(src):
 if any(token in line for token in ('%123 =','%871 =','scratch_store_dword','scratch_load_dword')):
  indices.update(range(max(0,i-2),min(len(src),i+5)))
(out/'original-spill-excerpt.txt').write_text('\n'.join(f'{i+1}: {src[i]}' for i in sorted(indices))+'\n')
print(json.dumps(rows,indent=2))

# SPDX-License-Identifier: MIT
"""Preserve compiler IR and tested wave-tiles payloads without large GPU readbacks."""
from pathlib import Path
import hashlib,json,zipfile

root=Path('build/aco-runtime-trace')
out=Path('docs/test-evidence/mesa-aco-enc96-wave-tiles-experiment-2026-11-10')
files=list((root/'experiment-enc96/ir').rglob('*'))
files=[p for p in files if p.is_file()]
candidate=root/'experiment-enc96-wave-tiles'
files += [candidate/'data/shaders/enc_stage_96_128_128_fl_lt.spv',
          candidate/'records/gfx1201/openrr-d3d12-v1/91263369a61061b4.nrp',
          candidate/'reference/enc_stage_96_128_128.comp']
corrected=root/'experiment-enc96-wave-rcp'
files += [corrected/'data/shaders/enc_stage_96_128_128_fl_lt.spv',
          corrected/'records/gfx1201/openrr-d3d12-v1/f3817f3fb0a26545.nrp',
          corrected/'source-change.patch']
rows=[]
archive=out/'compiler-evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):
  data=p.read_bytes();name=p.relative_to(root).as_posix()
  z.writestr(name,data)
  rows.append({'file':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in rows:
  assert hashlib.sha256(z.read(row['file'])).hexdigest()==row['sha256']
result={'archive':archive.name,'bytes':archive.stat().st_size,
        'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':rows}
(out/'compiler-evidence.json').write_text(json.dumps(result,indent=2)+chr(10))
print(json.dumps({k:v for k,v in result.items() if k!='files'},indent=2))

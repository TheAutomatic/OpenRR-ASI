# SPDX-License-Identifier: MIT
"""Prove scoped FC1 source matches tested SPIR-V and other runtime variants."""
from pathlib import Path
import sys,subprocess,json,hashlib,concurrent.futures
sys.path.insert(0,'asi/build')
from build_shaders import parse_fastmode,parse_shader_lists
from build_aco_records import fnv
source=Path('gpu/shaders');out=Path('build/aco-runtime-trace/experiment-address-screen/source-verification')
out.mkdir(exist_ok=True)
flow=parse_shader_lists('gpu')[1];lt=parse_fastmode('gpu/fastmode.cmake')
names=['enc_stage_96_128_128','enc_stage_128_128_160','dec_dfn_96_128','dec_dfn_64_64','dec_up_64_64_96','enc_stage_64_64_96','dec_head_32_64']
jobs=[]
for name in names:
 variants={'':[],'_f':['ENC_F32=1'],'_f_lt':['ENC_F32=1']+lt[name]}
 if name in flow:
  slot=flow.index(name);defs=['ENC_F32=1','FLOW=1',f'FLOW_SLOT={slot}',f'FLOW_WAIT={int(slot>0)}']
  variants.update({'_fl':defs,'_fl_lt':defs+lt[name]})
 for suffix,defs in variants.items():
  file=name+suffix+'.spv'
  expected=Path('build/asi/stage/openrr-amd/shaders')/file
  if name=='enc_stage_96_128_128' and suffix=='_fl_lt':expected=Path('build/aco-runtime-trace/experiment-enc96-wave-rcp/data/shaders')/file
  if name=='dec_dfn_96_128' and suffix=='_fl_lt':expected=Path('build/aco-runtime-trace/experiment-address-screen/dec_dfn_96_128/candidate/data/shaders')/file
  if expected.exists():jobs.append((name,file,defs,expected))
def verify(job):
 name,file,defs,expected=job;dest=out/file
 subprocess.run(['glslangValidator','-V','--target-env','vulkan1.3',*[f'-D{d}' for d in defs],'-Igpu/shaders/include',str(source/(name+'.comp')),'-o',str(dest)],check=True,capture_output=True)
 b=dest.read_bytes();assert b==expected.read_bytes(),file
 return {'shader':file,'spv_fnv':f'{fnv(b):016x}','sha256':hashlib.sha256(b).hexdigest(),'matches':str(expected)}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(verify,jobs))
dest=Path('docs/test-evidence/mesa-aco-address-screen-2026-11-10/source-verification.json')
dest.write_text(json.dumps(rows,indent=2)+chr(10));print(f'{len(rows)} selected and unchanged runtime variants match expected bytes')
full=Path('build/aco-runtime-trace/experiment-address-screen/full-source-verification')
if full.exists():
 rows=[]
 for p in sorted(full.glob('*.spv')):
  expected=Path('build/aco-runtime-trace/experiment-address-screen/dec_dfn_96_128/candidate/data/shaders')/p.name
  assert expected.exists() and p.read_bytes()==expected.read_bytes(),p.name
  rows.append({'shader':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 (dest.parent/'full-source-verification.json').write_text(json.dumps(rows,indent=2)+chr(10))
 print(f'Full runtime build: {len(rows)} SPIR-V files match tested data bytes')

# SPDX-License-Identifier: MIT
"""Archive machine-code evidence including scalar-base addressing and provenance."""
from pathlib import Path
import json,re,hashlib,zipfile,shutil
root=Path('build/aco-runtime-trace/experiment-cmat-address')
out=Path('docs/test-evidence/mesa-aco-cmat-address-2026-11-10')
rows=json.loads((out/'screen.json').read_text())
previous=Path('build/aco-runtime-trace/experiment-address-screen')
for row in rows:
 name=row['shader'];stem=name.removesuffix('_fl_lt')
 ref=previous/stem/('fc1-address' if stem=='dec_dfn_96_128' else 'original')/'capture.code'
 assert (root/name/'off/capture.code').read_bytes()==ref.read_bytes(),name
 row['off_matches_accepted_code']=True
 for role in ('off','on'):
  nir=next((root/name/role).glob('*.0.txt')).read_text()
  ir=next((root/name/role).glob('*.2.txt')).read_text().split('After lowering to hw instructions:',1)[1]
  loads=[s for s in ir.splitlines() if re.search('= global_load_dword',s)]
  scalar=[s for s in loads if re.search(', %[0-9]+:s',s)]
  row[role]['scalar_base_global_loads']=len(scalar)
  row[role]['total_static_global_loads']=len(loads)
  row[role]['con_loops_in_final_nir']=len(re.findall('con loop [{]',nir))
  row[role]['nir_64_ops']={op:len(re.findall(r'(?:con|div) 64 +%[0-9]+ = '+op+' ',nir)) for op in ('iadd','ishl','imul')}
  row[role]['scalar_base_examples']=scalar[:8]
(out/'screen.json').write_text(json.dumps(rows,indent=2)+chr(10))
files=[Path('asi/build/mesa/global-address.patch'),Path('asi/build/mesa/prepare_global_address.py'),Path('asi/tests/cmat_address_screen.py'),Path('asi/tests/cmat_address_boundaries.py'),Path('asi/tests/prepare_cmat_address_candidates.py'),root/'toolchain.json',out/'boundaries.json']
files+=list(root.rglob('*.spv'))
for name in ('enc_stage_96_128_128_fl_lt','dec_dfn_96_128_fl_lt'):
 records=root/name/'candidate/records/gfx1201/openrr-d3d12-v1'
 manifest=json.loads((records/'manifest.json').read_text())
 target=next(k for k,r in manifest['records'].items() if r['spv']==name+'.spv')
 files += [records/(target+'.nrp'),records/'manifest.json',records/'manifest.msgpack']
files += [root/'isolated-toolchain.json'] if (root/'isolated-toolchain.json').exists() else []
files+=[p for p in root.rglob('*') if p.is_file() and p.suffix in ('.txt','.code','.layouts','.log') and 'data' not in p.parts]
members=[]
with zipfile.ZipFile(out/'compiler-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(set(files)):
  data=p.read_bytes();z.writestr(p.as_posix(),data);members.append({'path':p.as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
archive=out/'compiler-evidence.zip'
(out/'archive.json').write_text(json.dumps({'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':members},indent=2)+chr(10))
for row in rows:
 print(row['shader'],[(r,row[r]['scalar_base_global_loads'],row[r]['total_static_global_loads'],row[r]['con_loops_in_final_nir'],row[r]['nir_64_ops']) for r in ('off','on')])

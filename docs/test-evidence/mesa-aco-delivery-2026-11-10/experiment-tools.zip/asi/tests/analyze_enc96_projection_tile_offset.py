# SPDX-License-Identifier: MIT
from pathlib import Path
from collections import Counter
import re,json
base=Path('build/aco-runtime-trace/experiment-enc96/ir');root=Path('build/aco-runtime-trace/experiment-enc96-projection-tile-offset')
rows={}
for label in ('original','projection-tile-offset'):
 p=base/label;text=next(p.glob('*.2.txt')).read_text().split('After lowering to hw instructions:',1)[1]
 ops=Counter()
 for line in text.splitlines():
  m=re.search(r'\b([sv]_[a-z0-9_]+|ds_[a-z0-9_]+|global_[a-z0-9_]+|scratch_[a-z0-9_]+|image_[a-z0-9_]+)\b',line)
  if m:ops[m[1]]+=1
 rows[label]={'resources':json.loads((p/'capture.json').read_text()),'static_instruction_counts':dict(sorted(ops.items()))}
rows['note']='Existing tiled weight layout addressed directly without general WT divisions.'
(root/'instruction-comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
ops=[rows[k]['static_instruction_counts'] for k in ('original','projection-tile-offset')]
print(json.dumps({k:[ops[0].get(k,0),ops[1].get(k,0)] for k in sorted(set(ops[0])|set(ops[1])) if ops[0].get(k,0)!=ops[1].get(k,0)},indent=2))

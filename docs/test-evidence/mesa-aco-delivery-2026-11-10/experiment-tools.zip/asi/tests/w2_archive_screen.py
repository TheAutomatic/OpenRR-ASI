# SPDX-License-Identifier: MIT
"""Preserve small offline screening evidence, not runtime readbacks."""
from pathlib import Path
import hashlib,json,zipfile,shutil
root=Path('build/aco-runtime-trace/experiment-w2-screen')
out=Path('docs/test-evidence/mesa-aco-w2-screen-2026-11-10');out.mkdir(exist_ok=True)
files=[]
for path in root.iterdir():
 if path.is_dir() and path.name!='shortlist':
  for role in ('original','single-tile'):
   for p in (path/role).iterdir():
    if p.is_file():files.append(p)
for p in (root/'shortlist').rglob('*.nrp'):
 if p.name in ('8df4481367098c34.nrp','bbfd504de9eb12ec.nrp'):files.append(p)
archive=out/'compiler-evidence.zip';rows=[]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):
  data=p.read_bytes();name=p.relative_to(root).as_posix();z.writestr(name,data)
  rows.append({'file':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in rows:assert hashlib.sha256(z.read(row['file'])).hexdigest()==row['sha256']
(out/'compiler-evidence.json').write_text(json.dumps({'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':rows},indent=2)+chr(10))
for name in ('dec_dfn_64_64','dec_up_64_64_96'):
 shutil.copy2(root/'shortlist'/name/'records/gfx1201/openrr-d3d12-v1/manifest.json',out/(name+'-manifest.json'))
print('Archived',len(rows),'files,',archive.stat().st_size,'bytes')

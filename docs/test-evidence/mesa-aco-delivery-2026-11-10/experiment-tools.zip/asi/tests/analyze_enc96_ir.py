# SPDX-License-Identifier: MIT
"""Static IR evidence for merge-address experiment; no dynamic cost estimates."""
from pathlib import Path
from collections import Counter
import json,re
root=Path('build/aco-runtime-trace/experiment-enc96')
result={}
for label in ('original','merge-address'):
 p=root/'ir'/label;hw=next(p.glob('*.2.txt')).read_text().split('After lowering to hw instructions:',1)[1]
 ops=Counter()
 for line in hw.splitlines():
  m=re.search(r'\b([sv]_[a-z0-9_]+|ds_[a-z0-9_]+|global_[a-z0-9_]+|scratch_[a-z0-9_]+|image_[a-z0-9_]+)\b',line)
  if m:ops[m[1]]+=1
 ir=next(p.glob('*.1.txt')).read_text().splitlines()
 spill=[]
 for i,line in enumerate(ir):
  if 'scratch_' in line:spill.append({'line':i+1,'instruction':line.strip()})
 result[label]={'resources':json.loads((p/'capture.json').read_text()),'static_instruction_counts':dict(sorted(ops.items())),'spill_operations':spill}
ops=[r['static_instruction_counts'] for r in result.values()]
diff={k:[ops[0].get(k,0),ops[1].get(k,0)] for k in sorted(set(ops[0])|set(ops[1])) if ops[0].get(k,0)!=ops[1].get(k,0)}
result['changed_static_counts']=diff
manifest=json.loads((root/'records/gfx1201/openrr-d3d12-v1/manifest.json').read_text())
result['identities']={key:{k:manifest['records'][key][k] for k in ('spv_hash','code_hash')} for key in ('581ef3189b0a0052','bd2f725d3d958594')}
(root/'instruction-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(diff,indent=2))

# SPDX-License-Identifier: MIT
"""Four cells: one MLP loop DontUnroll x bounded-lane address switch."""
from pathlib import Path
import json,shutil,subprocess,os,sys,hashlib,re,difflib
from collections import Counter
sys.path.insert(0,'asi/build')
from build_shaders import parse_fastmode,parse_shader_lists
from build_aco_records import fnv
root=Path('build/aco-runtime-trace/experiment-enc128-unroll')
out=Path('docs/test-evidence/mesa-aco-enc128-unroll-2026-11-10');out.mkdir(exist_ok=True)
source=root/'source';shutil.copytree('gpu/shaders',source,dirs_exist_ok=True)
p=source/'include/onr_block_fast.glsl';old=p.read_text()
anchor='    J_UNROLL for (uint j = 0u; j < LT_HID; j += SLICE) {'
old=old.replace('    MLP_SLICE_LOOP for (uint j = 0u; j < LT_HID; j += SLICE) {',anchor)
assert old.count(anchor)==1
new=old.replace(anchor,'    [[dont_unroll]] for (uint j = 0u; j < LT_HID; j += SLICE) {')
p.write_text(new)
(out/'loop-source.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/onr_block_fast.glsl',tofile='b/onr_block_fast.glsl')))
name='enc_stage_128_128_160';flow=parse_shader_lists('gpu')[1];slot=flow.index(name)
defs=['ENC_F32=1','FLOW=1',f'FLOW_SLOT={slot}',f'FLOW_WAIT={int(slot>0)}']+parse_fastmode('gpu/fastmode.cmake')[name]
spv=root/(name+'_fl_lt.spv')
subprocess.run(['glslangValidator','-V','--target-env','vulkan1.3',*[f'-D{x}' for x in defs],f'-I{source}/include',str(source/(name+'.comp')),'-o',str(spv)],check=True)
subprocess.run(['spirv-dis',str(spv),'-o',str(root/'limited.spvasm')],check=True)
cfg=json.loads(Path('build/aco-runtime-trace/experiment-cmat-address/isolated-toolchain.json').read_text())
rows=[]
for control in ('original','limited'):
 for address in ('off','on'):
  if control=='original':
   dest=Path('build/aco-runtime-trace/experiment-cmat-address')/(name+'_fl_lt')/address
   shader=Path('build/aco-runtime-trace/experiment-address-screen/dec_dfn_96_128/candidate/data/shaders')/spv.name
  else:
   dest=root/('limited-'+address);dest.mkdir(exist_ok=True);shader=spv
   env=dict(os.environ,VK_ICD_FILENAMES=cfg['icd'],LD_PRELOAD=cfg['shim'],LD_LIBRARY_PATH=cfg['library_path'],AMDGPU_GPU_ID='gfx1201',MESA_SHADER_CACHE_DISABLE='true',ONR_ACO_PRECISION='global',ONR_ACO_VECTOR_LOADS='1',ONR_ACO_CAPTURE=str((dest/'capture').resolve()),ONR_ACO_ADDR32_HI='0x13579bdf',ONR_ISA=str(dest.resolve()))
   env.pop('ONR_ACO_CMAT_ADDRESS',None)
   if address=='on':env['ONR_ACO_CMAT_ADDRESS']='1'
   r=subprocess.run([str(Path('build/aco-tools/aco_capture').resolve()),str(shader.resolve())],env=env,text=True,capture_output=True)
   (dest/'compile.log').write_text(r.stdout+r.stderr);r.check_returncode()
  nir=next(dest.glob('*.0.txt')).read_text();ir=next(dest.glob('*.2.txt')).read_text().split('After lowering to hw instructions:',1)[1]
  ops=Counter()
  for line in ir.splitlines():
   m=re.search(r'([sv]_[a-z0-9_]+|global_[a-z0-9_]+|ds_[a-z0-9_]+|scratch_[a-z0-9_]+)',line)
   if m:ops[m[1]]+=1
  loads=[l for l in ir.splitlines() if '= global_load_dword' in l]
  rows.append({'control':control,'address':address,'spv_fnv':f'{fnv(shader.read_bytes()):016x}','spv_sha256':hashlib.sha256(shader.read_bytes()).hexdigest(),'code_sha256':hashlib.sha256((dest/'capture.code').read_bytes()).hexdigest(),'resources':json.loads((dest/'capture.json').read_text()),'opcodes':dict(ops),'global_load_count':len(loads),'scalar_base_count':sum(bool(re.search(', %[0-9]+:s',l)) for l in loads),'loops_final_nir':nir.count('con loop {'),'artifact':str(dest)})
(out/'screen.json').write_text(json.dumps(rows,indent=2)+chr(10))
for r in rows:print(r['control'],r['address'],r['spv_fnv'],r['resources'],'loads',r['global_load_count'],'scalar',r['scalar_base_count'])

# SPDX-License-Identifier: MIT
from pathlib import Path
import json,os,subprocess
root=Path('build/aco-runtime-trace/experiment-enc128-unroll')
cfg=json.loads(Path('build/aco-tools/toolchain.json').read_text())
spv=Path('build/aco-runtime-trace/experiment-address-screen/dec_dfn_96_128/candidate/data/shaders/enc_stage_128_128_160_fl_lt.spv')
for role in ('off','on'):
 d=root/('probe-'+role);d.mkdir(exist_ok=True)
 env=dict(os.environ,VK_ICD_FILENAMES=cfg['icd'],LD_PRELOAD=cfg['shim'],LD_LIBRARY_PATH=cfg['library_path'],AMDGPU_GPU_ID='gfx1201',MESA_SHADER_CACHE_DISABLE='true',ONR_ACO_PRECISION='global',ONR_ACO_VECTOR_LOADS='1',ONR_ACO_CAPTURE=str((d/'capture').resolve()),ONR_ACO_ADDR32_HI='0x13579bdf',ONR_UNROLL_PROBE='1')
 env.pop('ONR_ACO_CMAT_ADDRESS',None)
 if role=='on':env['ONR_ACO_CMAT_ADDRESS']='1'
 r=subprocess.run([str(Path('build/aco-tools/aco_capture').resolve()),str(spv.resolve())],env=env,text=True,capture_output=True)
 (d/'probe.log').write_text(r.stdout+r.stderr);r.check_returncode()
 print(role)
 for s in (r.stdout+r.stderr).splitlines():
  if s.startswith(('ONR_UNROLL ','ONR_PRE ')):print(s)

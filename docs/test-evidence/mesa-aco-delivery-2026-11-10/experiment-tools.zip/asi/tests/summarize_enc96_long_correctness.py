# SPDX-License-Identifier: MIT
"""Archive all-frame long-run quality and locate the first changed output."""
from pathlib import Path
import hashlib,json,shutil,csv
import array,sys
assert sys.byteorder=='little'
name=sys.argv[1] if len(sys.argv)>1 else 'enc96-wave-long-correctness'
root=Path('build/aco-runtime-trace/runs-approved-2026-11-10')/name
out=Path('docs/test-evidence/mesa-aco-enc96-wave-tiles-experiment-2026-11-10')/name
out.mkdir(exist_ok=True)
summary=json.loads((root/'summary.json').read_text())
assert summary['parity_passed'] and summary['parity_coverage']=='all_measured_frames'
rows=[];first=None
for phase,count in [('steady',280),('drs',12)]:
 for i in range(count):
  a=(root/f'baseline-{phase}-{i}.bin').read_bytes();b=(root/f'candidate-{phase}-{i}.bin').read_bytes()
  row={'phase':phase,'index':i,'engine_frame':8+i if phase=='steady' else 288+i,
       'original_sha256':hashlib.sha256(a).hexdigest(),'candidate_sha256':hashlib.sha256(b).hexdigest(),
       'equal':a==b}
  if first is None and a!=b:
   aa=array.array('H');aa.frombytes(a);bb=array.array('H');bb.frombytes(b)
   diff=[i for i,(x,y) in enumerate(zip(aa,bb)) if x!=y]
   nonzero=[i for i in diff if (aa[i]|bb[i])&0x7fff]
   first=dict(row,differing_halfwords=len(diff),first_halfword=int(diff[0]),
              original_bits=int(aa[diff[0]]),candidate_bits=int(bb[diff[0]]),
              first_nonzero_halfword=int(nonzero[0]) if len(nonzero) else None)
  rows.append(row)
states=[]
for label in ('baseline','candidate'):
 with (root/f'{label}-frame-state.csv').open() as f:
  states.append([{k:v for k,v in r.items() if k!='call'} for r in csv.DictReader(f) if r['phase']!='building'])
assert states[0]==states[1]
for name in ('summary.json','baseline-frame-state.csv','candidate-frame-state.csv','openrr_baseline.log','openrr_candidate.log'):
 shutil.copy2(root/name,out/name)
result={'states_match':True,'first_changed_output':first,'outputs':rows}
(out/'output-comparison.json').write_text(json.dumps(result,indent=2)+chr(10))
print(json.dumps({'first_changed_output':first,'exact_frames':sum(r['equal'] for r in rows),'frames':len(rows)},indent=2))

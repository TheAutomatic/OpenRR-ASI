# SPDX-License-Identifier: MIT
from pathlib import Path
import hashlib,json,shutil
runs=Path('build/aco-runtime-trace/runs-next-optimization-2026-11-10')
trace=runs/'cmat-dec96-trace6/Correctness/round-0'
out=Path('docs/test-evidence/mesa-aco-cmat-address-2026-11-10/trace6');out.mkdir(exist_ok=True)
old=Path('build/aco-runtime-trace/runs-approved-2026-11-10/fast-address-dec96-trace-6/candidate-trace-6')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for label in ('baseline','candidate'):
 for phase,count in [('steady',8),('drs',12)]:
  for i in range(count):
   name=f'{label}-{phase}-{i}.bin'
   a=trace/name;b=runs/'cmat-dec96/Correctness/round-0'/name
   assert digest(a)==digest(b),name
 a=trace/f'{label}-trace-6'
 assert {p.name for p in a.glob('*.bin')}=={p.name for p in old.glob('*.bin')}
 for p in sorted(old.glob('*.bin')):
  h=digest(p);assert h==digest(a/p.name),(label,p.name)
  rows.append({'label':label,'file':p.name,'sha256':h})
 d=out/f'{label}-trace-6';d.mkdir(exist_ok=True)
 for name in ('trace.txt','aco-manifest.json'):
  if (a/name).exists():shutil.copy2(a/name,d/name)
for p in trace.iterdir():
 if p.suffix in ('.json','.csv','.log'):shutil.copy2(p,out/p.name)
(out/'hashes.json').write_text(json.dumps({'traced_untraced_equal':True,'prior_aco_case_equal':True,'readbacks':rows},indent=2)+chr(10))
print('Both ACO sides: 20 traced/untraced outputs and 69 readbacks match the retained frame6 case')

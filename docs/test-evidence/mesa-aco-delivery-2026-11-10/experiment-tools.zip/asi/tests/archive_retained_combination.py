# SPDX-License-Identifier: MIT
from pathlib import Path
import hashlib,json,shutil
runs=Path('build/aco-runtime-trace/runs-approved-2026-11-10')
out=Path('docs/test-evidence/mesa-aco-enc128-unroll-2026-11-10/combination-correctness');out.mkdir(exist_ok=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks={}
for label in ('baseline','candidate'):
 outputs=[]
 for phase,count in [('steady',8),('drs',12)]:
  for i in range(count):
   name=f'{label}-{phase}-{i}.bin'
   paths=[runs/r/name for r in ('fast-address-dec96-trace-6','combination-fast-control','combination-fast-trace6')]
   hashes=[digest(p) for p in paths];assert len(set(hashes))==1,name
   outputs.append({'file':name,'sha256':hashes[0]})
 a=runs/'fast-address-dec96-trace-6'/f'{label}-trace-6';b=runs/'combination-fast-trace6'/f'{label}-trace-6'
 assert {p.name for p in a.glob('*.bin')}=={p.name for p in b.glob('*.bin')}
 readbacks=[]
 for p in sorted(a.glob('*.bin')):
  h=digest(p);assert h==digest(b/p.name),(label,p.name)
  readbacks.append({'file':p.name,'sha256':h})
 checks[label]={'outputs':outputs,'readbacks':readbacks}
legacy=json.loads((runs/'combination-legacy-control/summary.json').read_text())
assert legacy['parity_passed'] and all(v['max_ulp_diff']==0 and v['exact_percent']==100 for v in legacy['parity'].values())
for name in ('combination-fast-control','combination-legacy-control','combination-fast-trace6'):
 dest=out/name;dest.mkdir(exist_ok=True)
 for p in (runs/name).iterdir():
  if p.suffix in ('.json','.csv','.log'):shutil.copy2(p,dest/p.name)
  if p.is_dir():
   d=dest/p.name;d.mkdir(exist_ok=True)
   for f in ('trace.txt','aco-manifest.json'):
    if (p/f).exists():shutil.copy2(p/f,d/f)
(out/'hashes.json').write_text(json.dumps({'legacy20_exact':True,'traced_untraced_equal':True,'prior_case_equal':True,'compilers':checks},indent=2)+chr(10))
print('Combination: Fast20 and 69 readbacks per compiler reproduce prior case; Legacy20 exact')

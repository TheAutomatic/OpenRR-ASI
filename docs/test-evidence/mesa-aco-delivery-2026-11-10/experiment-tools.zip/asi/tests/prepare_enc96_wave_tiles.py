# SPDX-License-Identifier: MIT
"""One token tile per wave: existing transposed body instead of W2 body."""
from pathlib import Path
import shutil,subprocess,sys,json
sys.path.insert(0,'asi/build')
from build_shaders import parse_shader_lists,parse_fastmode
from build_aco_records import fnv
from enc96_experiment_source import baseline_shader
root=Path('build/aco-runtime-trace/experiment-enc96-wave-tiles')
data=root/'data/shaders';data.mkdir(parents=True,exist_ok=True)
for f in Path('build/asi/stage/openrr-amd/shaders').glob('*.spv'):shutil.copy2(f,data/f.name)
name='enc_stage_96_128_128';flow=parse_shader_lists('gpu')[1];slot=flow.index(name)
defs=['ENC_F32=1','FLOW=1',f'FLOW_SLOT={slot}',f'FLOW_WAIT={int(slot>0)}']+parse_fastmode('gpu/fastmode.cmake')[name]
base=root/'reference';base.mkdir(exist_ok=True);spvname=name+'_fl_lt.spv'
src=baseline_shader(root)
for extra,dst in [([],base/spvname),(['-DW2=0'],data/spvname)]:
 subprocess.run(['glslangValidator','-V','--target-env','vulkan1.3',*[f'-D{d}' for d in defs],*extra,'-Igpu/shaders/include',str(src),'-o',str(dst)],check=True)
assert (base/spvname).read_bytes()==(Path('build/asi/stage/openrr-amd/shaders')/spvname).read_bytes()
(root/'source-change.patch').write_text('Isolated compile define W2=0 for enc_stage_96_128_128_fl_lt only. Existing source unchanged.\n')
print(json.dumps({'baseline_spv':f'{fnv((base/spvname).read_bytes()):016x}','candidate_spv':f'{fnv((data/spvname).read_bytes()):016x}','defines':defs+['W2=0']},indent=2))

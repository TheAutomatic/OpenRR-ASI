# SPDX-License-Identifier: MIT
# ACO/ACO correctness through the extended timing sequence; not a speed test.
param([string]$Name='enc96-wave-long-correctness', [int]$Frames=280,
      [int]$DrsFrames=12, [int]$TraceFrame=-1, [int]$AllFrames=1,
      [string]$Experiment='experiment-enc96-wave-tiles')
$ErrorActionPreference='Stop'
Set-Location -LiteralPath (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$tool=Join-Path (Get-Location) 'build/aco-runtime-trace'
$env:ONR_ACO_DIR=Join-Path $tool "$Experiment/records/gfx1201/openrr-d3d12-v1"
$env:ONR_RR_FLOW='1'
foreach($envName in @('ONR_RR_STAMPS','ONR_RR_TRACE_KERNEL','ONR_RR_NO_SAMPLER','ONR_RR_DIRECT_GUIDES','ONR_RR_DIRECT')) {
 Remove-Item -LiteralPath "Env:$envName" -ErrorAction SilentlyContinue
}
$dest=Join-Path $tool "runs-approved-2026-11-10/$Name"
if(Test-Path -LiteralPath $dest){throw 'Refusing to overwrite a saved correctness run'}
New-Item -ItemType Directory -Path $dest | Out-Null
$runtime=Join-Path $tool 'openrr-trace.asi'
$benchArgs=@('--runtime',$runtime,'--baseline-runtime',$runtime,
 '--baseline-data-dir','build/asi/stage/openrr-amd','--data-dir',(Join-Path $tool "$Experiment/data"),
 '--baseline-compiler','aco-strict','--candidate-compiler','aco-strict',
 '--rw','1280','--rh','720','--ow','1920','--oh','1080',
 '--warmup','8','--frames',"$Frames",'--drs-frames',"$DrsFrames",'--fast-mode','1','--optional-guides','0',
 '--parity-all-frames',"$AllFrames",'--align-engine-phase','1','--trace-frame',"$TraceFrame",'--out',$dest)
& (Join-Path $tool 'openrr_bench.exe') @benchArgs 2>&1 | Tee-Object -FilePath (Join-Path $dest 'console.log') | Out-Host
if($LASTEXITCODE -ne 0){throw 'Extended correctness failed'}
foreach($label in @('baseline','candidate')) {
 $log=Get-Content -LiteralPath (Join-Path $dest "openrr_$label.log") -Raw
 $paths=[regex]::Matches($log,'runtime paths: direct_guides=\d+ direct_output=\d+ sampler=\d+ flow=\d+')
 if($paths.Count -eq 0){throw 'Missing actual path diagnostics'}
 foreach($path in $paths){if($path.Value -ne 'runtime paths: direct_guides=1 direct_output=1 sampler=1 flow=1'){throw 'Unexpected runtime path'}}
}

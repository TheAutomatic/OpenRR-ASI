# SPDX-License-Identifier: MIT
"""Check the retained frame-6 case, including traced/untraced output identity."""
from pathlib import Path
import hashlib,json,shutil
runs=Path('build/aco-runtime-trace/runs-approved-2026-11-10')
out=Path('docs/test-evidence/mesa-aco-next-optimization-2026-11-10/address-dec96/trace6')
out.mkdir(parents=True,exist_ok=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
result={}
for label in ('baseline','candidate'):
 rows=[]
 for phase,count in [('steady',8),('drs',12)]:
  for i in range(count):
   name=f'{label}-{phase}-{i}.bin'
   paths=[runs/run/name for run in ('fast-enc96-wave-rcp-trace-6','fast-address-dec96-control','fast-address-dec96-trace-6')]
   hashes=[digest(p) for p in paths]
   assert len(set(hashes))==1,name
   rows.append({'file':name,'sha256':hashes[0]})
 a=runs/'fast-enc96-wave-rcp-trace-6'/f'{label}-trace-6'
 b=runs/'fast-address-dec96-trace-6'/f'{label}-trace-6'
 assert {p.name for p in a.glob('*.bin')}=={p.name for p in b.glob('*.bin')}
 readbacks=[]
 for p in sorted(a.glob('*.bin')):
  h=digest(p);assert h==digest(b/p.name),p.name
  readbacks.append({'file':p.name,'sha256':h})
 result[label]={'outputs':rows,'readbacks':readbacks}
for run in ('fast-address-dec96-control','fast-address-dec96-trace-6'):
 dest=out/run;dest.mkdir(exist_ok=True)
 for p in (runs/run).iterdir():
  if p.suffix in ('.json','.csv','.log'):shutil.copy2(p,dest/p.name)
  if p.is_dir():
   d=dest/p.name;d.mkdir(exist_ok=True)
   for name in ('trace.txt','aco-manifest.json'):shutil.copy2(p/name,d/name)
(out/'hashes.json').write_text(json.dumps(result,indent=2)+chr(10))
print('Frame6: both compilers reproduce prior 20 outputs and all 69 readbacks; traced/untraced equal.')

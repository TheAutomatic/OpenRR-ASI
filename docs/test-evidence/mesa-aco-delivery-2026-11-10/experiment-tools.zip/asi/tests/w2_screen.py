# SPDX-License-Identifier: MIT
"""Offline one-token-tile screen; no runtime or GPU execution."""
from pathlib import Path
from collections import Counter
import json,os,re,subprocess,sys,hashlib,shutil
sys.path.insert(0,'asi/build')
from build_shaders import parse_fastmode,parse_shader_lists
from build_aco_records import fnv
from enc96_experiment_source import before_address_source

ROOT=Path('build/aco-runtime-trace/experiment-w2-screen')
SOURCE=before_address_source(ROOT/'control-source')
STAGE=Path('build/asi/stage/openrr-amd/shaders')
NAMES=['dec_dfn_96_128','dec_dfn_64_64','dec_up_64_64_96','enc_stage_64_64_96']
cfg=json.loads(Path('build/aco-tools/toolchain.json').read_text())
flow=parse_shader_lists('gpu')[1];lite=parse_fastmode('gpu/fastmode.cmake')
rows=[]
for name in NAMES:
 suffix='_fl_lt' if name in flow else '_f_lt';filename=name+suffix+'.spv'
 defs=['ENC_F32=1']+lite[name]
 if name in flow:
  slot=flow.index(name);defs+=['FLOW=1',f'FLOW_SLOT={slot}',f'FLOW_WAIT={int(slot>0)}']
 pair={}
 for role in ('original','single-tile'):
  out=ROOT/name/role;out.mkdir(parents=True,exist_ok=True);spv=out/filename
  extra=[] if role=='original' else ['W2=0']
  if role=='single-tile' and name.startswith('enc_stage_'):extra+=['ENC_DFN_SIG_RCP=1']
  include=SOURCE/'include'
  if role=='single-tile' and name.startswith('dec_up_'):
   # W2 dec_up walks windows backwards. Keep that traversal when changing
   # tile count so scheduling order is not a second experimental factor.
   include=out/'include';shutil.copytree(SOURCE/'include',include,dirs_exist_ok=True)
   p=include/'onr_block_fast.glsl';text=p.read_text()
   old='ivec2 win = ivec2(int(gl_WorkGroupID.x) % pc.nwx, int(gl_WorkGroupID.x) / pc.nwx);'
   new='int wid_ = pc.nwx * ((pc.size.y + pc.shift.y + 7) / 8) - 1 - int(gl_WorkGroupID.x);'+chr(10)+'    ivec2 win = ivec2(wid_ % pc.nwx, wid_ / pc.nwx);'
   assert text.count(old)==2;p.write_text(text.replace(old,new))
   (out/'traversal-adaptation.txt').write_text('Preserve W2 reverse window traversal; no arithmetic changes.'+chr(10))
  command=['glslangValidator','-V','--target-env','vulkan1.3',*[f'-D{x}' for x in defs+extra],f'-I{include}',str(SOURCE/(name+'.comp')),'-o',str(spv)]
  r=subprocess.run(command,text=True,capture_output=True);(out/'glslang.log').write_text(r.stdout+r.stderr);r.check_returncode()
  if role=='original':assert spv.read_bytes()==(STAGE/filename).read_bytes(),filename
  env=dict(os.environ,VK_ICD_FILENAMES=cfg['icd'],LD_PRELOAD=cfg['shim'],AMDGPU_GPU_ID='gfx1201',MESA_SHADER_CACHE_DISABLE='true',LD_LIBRARY_PATH=cfg['library_path'],ONR_ACO_PRECISION='global',ONR_ACO_VECTOR_LOADS='1',ONR_ACO_ADDR32_HI='0x13579bdf',ONR_ACO_CAPTURE=str((out/'capture').resolve()),ONR_ISA=str(out.resolve()))
  r=subprocess.run([str(Path('build/aco-tools/aco_capture').resolve()),str(spv.resolve())],env=env,text=True,capture_output=True);(out/'capture.log').write_text(r.stdout+r.stderr);r.check_returncode()
  info=json.loads((out/'capture.json').read_text())
  text=next(out.glob('*.2.txt')).read_text().split('After lowering to hw instructions:',1)[1]
  ops=Counter()
  for line in text.splitlines():
   m=re.search(r'\b([sv]_[a-z0-9_]+|ds_[a-z0-9_]+|global_[a-z0-9_]+|scratch_[a-z0-9_]+|image_[a-z0-9_]+)\b',line)
   if m:ops[m[1]]+=1
  pair[role]={'spv_hash':f'{fnv(spv.read_bytes()):016x}','spv_sha256':hashlib.sha256(spv.read_bytes()).hexdigest(),'capture_code_sha256':hashlib.sha256((out/'capture.code').read_bytes()).hexdigest(),'defines':defs+extra,'resources':info,'static_instruction_counts':dict(sorted(ops.items()))}
 rows.append({'kernel':name+suffix,'variants':pair})
(ROOT/'results.json').write_text(json.dumps(rows,indent=2)+chr(10))
out=Path('docs/test-evidence/mesa-aco-w2-screen-2026-11-10');out.mkdir(parents=True,exist_ok=True)
shutil.copy2(ROOT/'results.json',out/'results.json')
print(json.dumps([{r['kernel']:{k:v['resources'] for k,v in r['variants'].items()}} for r in rows],indent=2))

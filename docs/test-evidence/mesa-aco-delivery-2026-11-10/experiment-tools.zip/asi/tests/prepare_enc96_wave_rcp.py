# SPDX-License-Identifier: MIT
"""Keep the W2 DFN reciprocal policy when selecting the transposed body."""
from pathlib import Path
import shutil,subprocess,sys,json,difflib
sys.path.insert(0,'asi/build')
from build_shaders import parse_fastmode
from build_aco_records import fnv
from enc96_experiment_source import baseline_shader
root=Path('build/aco-runtime-trace/experiment-enc96-wave-rcp');source=root/'source'
shutil.copytree('gpu/shaders',source,dirs_exist_ok=True)
baseline_shader(root,source)
p=source/'include/onr_block_fast.glsl';s=p.read_text()
old='float16_t g = float16_t(rcp_rn(e + 1.0));'
new='float16_t g = float16_t(SIG_RCP(e + 1.0));'
assert s.count(old)==1;p.write_text(s.replace(old,new))
name='enc_stage_96_128_128';defs=['ENC_F32=1','FLOW=1','FLOW_SLOT=0','FLOW_WAIT=0']+parse_fastmode('gpu/fastmode.cmake')[name]+['W2=0']
data=root/'data/shaders';data.mkdir(parents=True,exist_ok=True)
for f in Path('build/asi/stage/openrr-amd/shaders').glob('*.spv'):shutil.copy2(f,data/f.name)
dst=data/(name+'_fl_lt.spv')
subprocess.run(['glslangValidator','-V','--target-env','vulkan1.3',*[f'-D{d}' for d in defs],f'-I{source}/include',str(source/(name+'.comp')),'-o',str(dst)],check=True)
(root/'source-change.patch').write_text('W2=0 plus original W2 SIG_RCP policy for DFN gains.'+chr(10)+''.join(difflib.unified_diff(s.splitlines(True),s.replace(old,new).splitlines(True),fromfile='original/onr_block_fast.glsl',tofile='wave-rcp/onr_block_fast.glsl')))
print(json.dumps({'candidate_spv':f'{fnv(dst.read_bytes()):016x}','defines':defs},indent=2))

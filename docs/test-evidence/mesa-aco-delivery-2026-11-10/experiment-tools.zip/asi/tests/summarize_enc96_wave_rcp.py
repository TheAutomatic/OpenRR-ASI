# SPDX-License-Identifier: MIT
"""Archive corrected tiling tests and paired runtime timings."""
from pathlib import Path
import hashlib,json,shutil,statistics
runs=Path('build/aco-runtime-trace/runs-approved-2026-11-10')
experiment=Path('build/aco-runtime-trace/experiment-enc96-wave-rcp')
out=Path('docs/test-evidence/mesa-aco-enc96-wave-tiles-experiment-2026-11-10/corrected')
out.mkdir(exist_ok=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks={}
for label in ('baseline','candidate'):
 outputs=[]
 for phase,count in [('steady',8),('drs',12)]:
  for i in range(count):
   f=f'{label}-{phase}-{i}.bin'
   hashes=[digest(runs/name/f) for name in ('fast-aligned','fast-enc96-wave-rcp-control','fast-enc96-wave-rcp-trace-6')]
   assert len(set(hashes))==1,f
   outputs.append({'file':f,'sha256':hashes[0]})
 readbacks=[]
 a=runs/'fast-trace-6'/f'{label}-trace-6';b=runs/'fast-enc96-wave-rcp-trace-6'/f'{label}-trace-6'
 assert {p.name for p in a.glob('*.bin')}=={p.name for p in b.glob('*.bin')}
 for p in sorted(a.glob('*.bin')):
  h=digest(p);assert h==digest(b/p.name),p.name
  readbacks.append({'file':p.name,'sha256':h})
 checks[label]={'outputs':outputs,'trace6':readbacks}
 a=runs/'enc96-wave-trace-139'/f'{label}-trace-139'
 b=runs/'enc96-wave-rcp-trace-139'/f'{label}-trace-139'
 # Corrected trace139 must match untraced corrected output and original ACO trace.
 assert digest(b/'output.bin')==digest(runs/'enc96-wave-rcp-long-correctness'/f'{label}-steady-131.bin')
 if label=='baseline':reference=a
 else:reference=runs/'enc96-wave-trace-139/baseline-trace-139'
 assert {p.name for p in reference.glob('*.bin')}=={p.name for p in b.glob('*.bin')}
 checks[label]['trace139']=[]
 for p in sorted(reference.glob('*.bin')):
  h=digest(p);assert h==digest(b/p.name),p.name
  checks[label]['trace139'].append({'file':p.name,'sha256':h})
for name in ('fast-enc96-wave-rcp-control','fast-enc96-wave-rcp-trace-6','enc96-wave-rcp-trace-139'):
 dest=out/name;dest.mkdir(exist_ok=True)
 for p in (runs/name).iterdir():
  if p.suffix in ('.json','.csv','.log'):shutil.copy2(p,dest/p.name)
  if p.is_dir():
   d=dest/p.name;d.mkdir(exist_ok=True)
   for name2 in ('trace.txt','aco-manifest.json'):
    if (p/name2).exists():shutil.copy2(p/name2,d/name2)
rows=[]
for p in sorted((runs/'enc96-wave-rcp-confirm').glob('round-*')):
 s=json.loads((p/'summary.json').read_text());o=json.loads((p/'order.json').read_text(encoding='utf-8-sig'))
 assert s['parity_passed']
 assert all(v['max_ulp_diff']==0 and v['exact_percent']==100 for v in s['parity'].values())
 row={'round':o['round'],'first':o['baseline_role']}
 for label in ('baseline','candidate'):
  for phase in ('steady','drs'):row[o[label+'_role']+'_'+phase+'_ms']=s[label][phase+'_median_ms']
 rows.append(row);dest=out/p.name;dest.mkdir(exist_ok=True)
 for f in p.iterdir():
  if f.suffix in ('.json','.csv','.log'):shutil.copy2(f,dest/f.name)
assert len(rows)==6
stats={}
for phase in ('steady','drs'):
 stats[phase]={}
 for role in ('original','variant'):
  v=[r[role+'_'+phase+'_ms'] for r in rows]
  stats[phase][role]={'median_ms':statistics.median(v),'min_ms':min(v),'max_ms':max(v)}
 stats[phase]['change_percent']=100*(stats[phase]['variant']['median_ms']/stats[phase]['original']['median_ms']-1)
 stats[phase]['paired_change_percent']=[100*(r['variant_'+phase+'_ms']/r['original_'+phase+'_ms']-1) for r in rows]
for name in ('source-change.patch',):shutil.copy2(experiment/name,out/name)
shutil.copy2(experiment/'records/gfx1201/openrr-d3d12-v1/manifest.json',out/'manifest.json')
result={'correctness':checks,'rounds':rows,'statistics':stats}
(out/'results.json').write_text(json.dumps(result,indent=2)+chr(10))
print(json.dumps(stats,indent=2))

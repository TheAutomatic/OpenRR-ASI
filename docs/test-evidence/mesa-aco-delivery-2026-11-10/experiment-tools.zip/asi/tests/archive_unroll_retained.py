# SPDX-License-Identifier: MIT
from pathlib import Path
import json,zipfile,hashlib,subprocess,sys
root=Path('docs/test-evidence/mesa-aco-enc128-unroll-2026-11-10')
files=[Path(p) for p in ('gpu/shaders/enc_stage_96_128_128.comp','gpu/shaders/dec_dfn_96_128.comp','gpu/shaders/enc_stage_128_128_160.comp','gpu/shaders/include/onr_block.glsl','gpu/shaders/include/onr_block_fast.glsl','gpu/shaders/include/onr_block_w2.glsl','asi/build/build_asi.sh','asi/build/build_aco_records.py','asi/build/mesa/build_capture.sh','asi/build/mesa/prepare_global_address.py','asi/build/mesa/global-address.patch','build/aco-tools/toolchain.json')]
data=Path('build/aco-runtime-trace/retained-combination/data')
files+=list((data/'shaders').glob('*.spv'))
files += [p for p in (data/'aco/gfx1201/openrr-d3d12-v1').iterdir() if p.is_file()]
members=[]
with zipfile.ZipFile(root/'retained-combination.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files):
  b=p.read_bytes();z.writestr(p.as_posix(),b);members.append({'path':p.as_posix(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)})
archive=root/'retained-combination.zip'
(root/'retained-combination.json').write_text(json.dumps({'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':members},indent=2)+chr(10))
# Verify role-normalized actual compiler code in every final timing context.
expected={'enc_stage_96_128_128_fl_lt':'c08996618a61cd08','dec_dfn_96_128_fl_lt':'6a4ccda0cd2efb14','enc_stage_128_128_160_fl_lt':'591c303d1916df59'}
checks=[]
for name in ('enc128-unroll','enc128-unroll-confirm','combination-final'):
 for p in sorted((Path('build/aco-runtime-trace/runs-next-optimization-2026-11-10')/name).glob('Long/round-*')):
  order=json.loads((p/'order.json').read_text(encoding='utf-8-sig'))
  label='baseline' if order['baseline_role']=='variant' else 'candidate'
  text=(p/f'openrr_{label}.log').read_text()
  for shader,code in expected.items():
   found=[s for s in text.splitlines() if f'] {shader} spv=' in s]
   assert found and all(f'code={code} ' in s for s in found),(p,shader)
  checks.append({'run':str(p),'combination_label':label,'codes':expected})
(root/'combination-record-checks.json').write_text(json.dumps(checks,indent=2)+chr(10))
print(f'Archived {len(files)} inputs/records; checked {len(checks)} combination contexts')

# SPDX-License-Identifier: MIT
"""Serialize independent Q and V chains to reduce simultaneous FP32 tiles."""
from pathlib import Path
import shutil,subprocess,sys,json,difflib
sys.path.insert(0,'asi/build')
from build_shaders import parse_shader_lists,parse_fastmode
from build_aco_records import fnv
from enc96_experiment_source import baseline_shader
root=Path('build/aco-runtime-trace/experiment-enc96-qv-serial');source=root/'source'
shutil.copytree('gpu/shaders',source,dirs_exist_ok=True)
baseline_shader(root,source)
p=source/'include/onr_block_w2.glsl';s=p.read_text()
start=s.index('            QC8 fq00 =');end=s.index('\n        }\n#define VLAY ROW',start)
old=s[start:end]
new=r'''            { QC8 f00 = QC8(0.0), f01 = QC8(0.0), f10 = QC8(0.0), f11 = QC8(0.0);
#define Q_K8(n) { QA8 a0_, a1_; \
            coopMatLoad(a0_, E4View(wa8).v, wq + uint(n) * 16u, ENC_C, ROW); coopMatLoad(a1_, E4View(wa8).v, wq + 16u * ENC_C + uint(n) * 16u, ENC_C, ROW); \
            MMA(f00, a0_, y0##n) MMA(f01, a1_, y0##n) MMA(f10, a0_, y1##n) MMA(f11, a1_, y1##n) }
              W2T(Q_K8)
              q00 = MH(f00), q01 = MH(f01), q10 = MH(f10), q11 = MH(f11); }
            { QC8 f00 = QC8(0.0), f01 = QC8(0.0), f10 = QC8(0.0), f11 = QC8(0.0);
#define V_K8(n) { QA8 b0_, b1_; \
            coopMatLoad(b0_, E4View(wb8).v, wq + uint(n) * 16u, ENC_C, ROW); coopMatLoad(b1_, E4View(wb8).v, wq + 16u * ENC_C + uint(n) * 16u, ENC_C, ROW); \
            MMA(f00, b0_, y0##n) MMA(f01, b1_, y0##n) MMA(f10, b0_, y1##n) MMA(f11, b1_, y1##n) }
              W2T(V_K8)
              v00 = MH(f00), v01 = MH(f01), v10 = MH(f10), v11 = MH(f11); }'''
p.write_text(s.replace(old,new))
name='enc_stage_96_128_128';flow=parse_shader_lists('gpu')[1];slot=flow.index(name)
defs=['ENC_F32=1','FLOW=1',f'FLOW_SLOT={slot}',f'FLOW_WAIT={int(slot>0)}']+parse_fastmode('gpu/fastmode.cmake')[name]
spvname=name+'_fl_lt.spv';base=root/'reference';base.mkdir(exist_ok=True)
data=root/'data/shaders';data.mkdir(parents=True,exist_ok=True)
for f in Path('build/asi/stage/openrr-amd/shaders').glob('*.spv'):shutil.copy2(f,data/f.name)
for inc,src,dst in [('gpu/shaders/include',base,base/spvname),(str(source/'include'),source,data/spvname)]:
 subprocess.run(['glslangValidator','-V','--target-env','vulkan1.3',*[f'-D{d}' for d in defs],f'-I{inc}',str(src/(name+'.comp')),'-o',str(dst)],check=True)
baseline=Path('build/asi/stage/openrr-amd/shaders')/spvname
assert (base/spvname).read_bytes()==baseline.read_bytes()
(root/'source-change.patch').write_text(''.join(difflib.unified_diff(s.splitlines(True),s.replace(old,new).splitlines(True),fromfile='original/onr_block_w2.glsl',tofile='qv-serial/onr_block_w2.glsl')))
print(json.dumps({'baseline_spv':f'{fnv(baseline.read_bytes()):016x}','candidate_spv':f'{fnv((data/spvname).read_bytes()):016x}','defines':defs},indent=2))

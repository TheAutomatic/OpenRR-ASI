# SPDX-License-Identifier: MIT
from pathlib import Path
import json,re,shutil,hashlib,zipfile
root=Path('build/aco-runtime-trace/experiment-enc128-unroll')
out=Path('docs/test-evidence/mesa-aco-enc128-unroll-2026-11-10');out.mkdir(exist_ok=True)
runs=Path('build/aco-runtime-trace/runs-next-optimization-2026-11-10/enc128-unroll/Profile')
rows=[]
for p in sorted(runs.glob('round-*')):
 order=json.loads((p/'order.json').read_text(encoding='utf-8-sig'))
 for label in ('baseline','candidate'):
  text=(p/f'openrr_{label}.log').read_text()
  samples=re.findall(r'timestamp intervals, mean of ([0-9]+) [(]ms[)]:([^\n]+)\n[^\n]*stamped dispatches:([^\n]+)',text)
  count,values,names=max(samples,key=lambda s:int(s[0]));values=[float(v) for v in values.split()]
  target=next(n for n in names.split() if n.startswith('enc_stage_128_128_160_fl_lt.spv@'));index=int(target.split('@')[1])
  rows.append({'round':order['round'],'role':order[label+'_role'],'samples':int(count),'target_ms':values[index]})
 dest=out/'profile'/p.name;dest.mkdir(parents=True,exist_ok=True)
 for f in p.iterdir():
  if f.suffix in ('.log','.json','.csv'):shutil.copy2(f,dest/f.name)
(out/'profile.json').write_text(json.dumps(rows,indent=2)+chr(10));print(json.dumps(rows,indent=2))
# The cost-only probe must reproduce the exact original cells.
probe=[]
for role in ('off','on'):
 d=root/('probe-'+role);ref=Path('build/aco-runtime-trace/experiment-cmat-address/enc_stage_128_128_160_fl_lt')/role
 assert (d/'capture.code').read_bytes()==(ref/'capture.code').read_bytes()
 shutil.copy2(d/'probe.log',out/('unroll-'+role+'.log'))
 probe.append({'address':role,'matches_prior_code':True})
(out/'probe-checks.json').write_text(json.dumps(probe,indent=2)+chr(10))
isa=Path('build/aco-runtime-trace/hotspot-resources/enc128-llpc.isa');shutil.copy2(isa,out/isa.name)
files=[p for p in root.rglob('*') if p.is_file() and 'candidate' not in p.parts and 'source' not in p.parts]
for role in ('off','on'):
 files += [p for p in (Path('build/aco-runtime-trace/experiment-cmat-address/enc_stage_128_128_160_fl_lt')/role).iterdir() if p.is_file()]
files += [out/'loop-source.patch',out/'screen.json']
members=[]
with zipfile.ZipFile(out/'compiler-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(set(files)):
  b=p.read_bytes();z.writestr(p.as_posix(),b);members.append({'path':p.as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(out/'archive.json').write_text(json.dumps({'members':members,'zip_sha256':hashlib.sha256((out/'compiler-evidence.zip').read_bytes()).hexdigest()},indent=2)+chr(10))

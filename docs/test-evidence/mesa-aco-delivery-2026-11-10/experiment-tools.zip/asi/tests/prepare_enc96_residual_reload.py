# SPDX-License-Identifier: MIT
"""Defer FP16 residual input loads until attention no longer needs FP8 input."""
from pathlib import Path
import shutil,subprocess,sys,json,difflib
sys.path.insert(0,'asi/build')
from build_shaders import parse_shader_lists,parse_fastmode
from build_aco_records import fnv
from enc96_experiment_source import baseline_shader
root=Path('build/aco-runtime-trace/experiment-enc96-residual-reload');source=root/'source'
shutil.copytree('gpu/shaders',source,dirs_exist_ok=True)
baseline_shader(root,source)
p=source/'include/onr_block_w2.glsl';s=p.read_text();new=s
start=s.index('#define XIN2Y(');end=s.index('\n#endif',start)
old=s[start:end]
replacement=r'''#define XIN2Y(xa, xb, ya, yb, tp, pl) QB8 ya, yb; { uvec4 w_ = U32x4View(uint64_t(pc.x)).v[plane_index(tp, int(pl) * 32 + int(hh) * 16) >> 4]; \
        [[unroll]] for (int k_ = 0; k_ < 4; ++k_) { \
            uint o_ = ocp4(w_[k_]); \
            ya[2 * k_] = uintBitsToFloate4m3EXT(uint8_t(o_ & 0xffu)), ya[2 * k_ + 1] = uintBitsToFloate4m3EXT(uint8_t((o_ >> 8) & 0xffu)); \
            yb[2 * k_] = uintBitsToFloate4m3EXT(uint8_t((o_ >> 16) & 0xffu)), yb[2 * k_ + 1] = uintBitsToFloate4m3EXT(uint8_t(o_ >> 24)); } }'''
new=new.replace(old,replacement)
marker='    // x1 = fma(O out^T + b, ls1, x)'
replacement='''#if FP8QV
    // Source input is read-only throughout attention. Reload FP16 residual here
    // rather than keeping it live beside FP8 inputs and all Q/V accumulators.
#define RELOAD_A(pl, a, b) XIN2(x0##a, x0##b, tpa, ra, uint(pl))
#define RELOAD_B(pl, a, b) XIN2(x1##a, x1##b, tpb, rb, uint(pl))
    W2P(RELOAD_A) W2P(RELOAD_B)
#endif
'''+marker
assert new.count(marker)==1
new=new.replace(marker,replacement);p.write_text(new)
name='enc_stage_96_128_128';flow=parse_shader_lists('gpu')[1];slot=flow.index(name)
defs=['ENC_F32=1','FLOW=1',f'FLOW_SLOT={slot}',f'FLOW_WAIT={int(slot>0)}']+parse_fastmode('gpu/fastmode.cmake')[name]
spvname=name+'_fl_lt.spv';base=root/'reference';base.mkdir(exist_ok=True)
data=root/'data/shaders';data.mkdir(parents=True,exist_ok=True)
for f in Path('build/asi/stage/openrr-amd/shaders').glob('*.spv'):shutil.copy2(f,data/f.name)
for inc,src,dst in [('gpu/shaders/include',base,base/spvname),(str(source/'include'),source,data/spvname)]:
 subprocess.run(['glslangValidator','-V','--target-env','vulkan1.3',*[f'-D{d}' for d in defs],f'-I{inc}',str(src/(name+'.comp')),'-o',str(dst)],check=True)
baseline=Path('build/asi/stage/openrr-amd/shaders')/spvname
assert (base/spvname).read_bytes()==baseline.read_bytes()
(root/'source-change.patch').write_text(''.join(difflib.unified_diff(s.splitlines(True),new.splitlines(True),fromfile='original/onr_block_w2.glsl',tofile='residual-reload/onr_block_w2.glsl')))
print(json.dumps({'baseline_spv':f'{fnv(baseline.read_bytes()):016x}','candidate_spv':f'{fnv((data/spvname).read_bytes()):016x}','defines':defs},indent=2))

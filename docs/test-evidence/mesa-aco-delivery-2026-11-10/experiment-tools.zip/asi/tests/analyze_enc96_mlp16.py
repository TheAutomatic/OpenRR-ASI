# SPDX-License-Identifier: MIT
from pathlib import Path
from collections import Counter
import re,json
base=Path('build/aco-runtime-trace/experiment-enc96/ir');root=Path('build/aco-runtime-trace/experiment-enc96-mlp16')
rows={}
for label in ('original','mlp16'):
 p=base/label;text=next(p.glob('*.2.txt')).read_text().split('After lowering to hw instructions:',1)[1]
 ops=Counter()
 for line in text.splitlines():
  m=re.search(r'\b([sv]_[a-z0-9_]+|ds_[a-z0-9_]+|global_[a-z0-9_]+|scratch_[a-z0-9_]+|image_[a-z0-9_]+)\b',line)
  if m:ops[m[1]]+=1
 rows[label]={'resources':json.loads((p/'capture.json').read_text()),'static_instruction_counts':dict(sorted(ops.items()))}
rows['note']='MLP loop iterations double from LT_HID/32 to LT_HID/16. Per-output FC1 K and FC2 K/rounding order unchanged. Static counts do not represent dynamic work.'
(root/'instruction-comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
ops=[rows[k]['static_instruction_counts'] for k in ('original','mlp16')]
print(json.dumps({k:[ops[0].get(k,0),ops[1].get(k,0)] for k in sorted(set(ops[0])|set(ops[1])) if ops[0].get(k,0)!=ops[1].get(k,0)},indent=2))

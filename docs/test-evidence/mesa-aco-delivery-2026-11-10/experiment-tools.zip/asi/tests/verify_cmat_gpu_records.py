# SPDX-License-Identifier: MIT
"""Verify identical-SPIR-V tests actually loaded distinct expected code records."""
from pathlib import Path
import json
root=Path('build/aco-runtime-trace/runs-next-optimization-2026-11-10')
expected={'cmat-enc96':('enc_stage_96_128_128_fl_lt','f3817f3fb0a26545','c08996618a61cd08','1ba94d9e00ca5ad3'),
          'cmat-dec96':('dec_dfn_96_128_fl_lt','607b418f7ed5346e','38ac98d35509933f','6a4ccda0cd2efb14')}
expected['cmat-dec96-confirm']=expected['cmat-dec96']
expected['cmat-dec96-trace6']=expected['cmat-dec96']
rows=[]
for case,(shader,spv,control,candidate) in expected.items():
 for order in sorted((root/case).glob('*/round-*/order.json')):
  o=json.loads(order.read_text(encoding='utf-8-sig'))
  for label in ('baseline','candidate'):
   role=o[label+'_role'];code=control if role=='original' else candidate
   text=(order.parent/f'openrr_{label}.log').read_text(encoding='utf-8-sig')
   matches=[s for s in text.splitlines() if f'{shader} spv={spv} compiler=ACO ' in s]
   assert matches and all(f'code={code} ' in s for s in matches),(order,label)
   rows.append({'run':str(order.parent),'label':label,'role':role,'spv':spv,'code':code})
out=Path('docs/test-evidence/mesa-aco-cmat-address-2026-11-10/gpu-record-checks.json')
out.write_text(json.dumps(rows,indent=2)+chr(10));print(f'{len(rows)} role/compiler identities checked')

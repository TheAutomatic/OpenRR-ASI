# SPDX-License-Identifier: MIT
"""Single factor: rebase Q/V BDA pointers per head, leaving tile offsets literal."""
from pathlib import Path
import shutil,subprocess,sys,json,difflib
sys.path.insert(0,'asi/build')
from build_shaders import parse_shader_lists,parse_fastmode
from build_aco_records import fnv
from enc96_experiment_source import baseline_shader
root=Path('build/aco-runtime-trace/experiment-enc96-qv-rebase');source=root/'source'
shutil.copytree('gpu/shaders',source,dirs_exist_ok=True)
baseline_shader(root,source)
p=source/'include/onr_block_w2.glsl';s=p.read_text()
start=s.index('            uint64_t wa8 =');end=s.index('\n        }\n#define VLAY ROW',start)
old=s[start:end]
new=old.replace('uint64_t(QV8_OFF)','uint64_t(QV8_OFF) + uint64_t(wq)').replace('wq + (n) * 16u','(n) * 16u').replace('wq + 16u * ENC_C + (n) * 16u','16u * ENC_C + (n) * 16u')
assert new!=old and new.count('uint64_t(wq)')==2
p.write_text(s.replace(old,new))
name='enc_stage_96_128_128';flow=parse_shader_lists('gpu')[1];slot=flow.index(name)
defs=['ENC_F32=1','FLOW=1',f'FLOW_SLOT={slot}',f'FLOW_WAIT={int(slot>0)}']+parse_fastmode('gpu/fastmode.cmake')[name]
spvname=name+'_fl_lt.spv';base=root/'reference';base.mkdir(exist_ok=True)
data=root/'data/shaders';data.mkdir(parents=True,exist_ok=True)
for f in Path('build/asi/stage/openrr-amd/shaders').glob('*.spv'):shutil.copy2(f,data/f.name)
for inc,src,dst in [('gpu/shaders/include',base,base/spvname),(str(source/'include'),source,data/spvname)]:
 subprocess.run(['glslangValidator','-V','--target-env','vulkan1.3',*[f'-D{d}' for d in defs],f'-I{inc}',str(src/(name+'.comp')),'-o',str(dst)],check=True)
baseline=Path('build/asi/stage/openrr-amd/shaders')/spvname
assert (base/spvname).read_bytes()==baseline.read_bytes()
(root/'source-change.patch').write_text(''.join(difflib.unified_diff(s.splitlines(True),s.replace(old,new).splitlines(True),fromfile='original/onr_block_w2.glsl',tofile='qv-rebase/onr_block_w2.glsl')))
print(json.dumps({'baseline_spv':f'{fnv(baseline.read_bytes()):016x}','candidate_spv':f'{fnv((data/spvname).read_bytes()):016x}','defines':defs},indent=2))

# SPDX-License-Identifier: MIT
$ErrorActionPreference='Stop'
$workspace=(Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$runs=Join-Path $workspace 'build/aco-runtime-trace/runs-approved-2026-11-10'
$evidence=Join-Path $workspace 'docs/test-evidence/mesa-aco-enc96-wave-tiles-experiment-2026-11-10'
$inventory=Get-Content -LiteralPath (Join-Path $evidence 'readback-inventory.json') -Raw | ConvertFrom-Json
$keepTraces=@('enc96-wave-trace-139','enc96-wave-rcp-trace-139','fast-enc96-wave-rcp-trace-6')
$plan=@()
foreach($run in $inventory){
 $dir=(Resolve-Path -LiteralPath (Join-Path $runs $run.run)).Path
 if(-not $dir.StartsWith($runs+[IO.Path]::DirectorySeparatorChar)){throw 'Outside experiment runs'}
 foreach($file in Get-ChildItem -LiteralPath $dir -Recurse -File -Filter '*.bin'){
  if($keepTraces -contains $run.run){continue}
  # Preserve first changed frame, immediately preceding output and long endpoint.
  if($run.run -like '*long-correctness' -and $file.Name -match '^(baseline|candidate)-steady-(130|131|279).bin$'){continue}
  $full=(Resolve-Path -LiteralPath $file.FullName).Path
  if(-not $full.StartsWith($dir+[IO.Path]::DirectorySeparatorChar)){throw 'Invalid deletion target'}
  $plan+=[pscustomobject]@{path=$full;bytes=$file.Length;run=$run.run}
 }
}
$dest=Join-Path $workspace 'docs/test-evidence/mesa-aco-next-optimization-2026-11-10'
New-Item -ItemType Directory -Path $dest -Force | Out-Null
$plan | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $dest 'cleanup-files.json') -Encoding utf8
foreach($file in $plan){Remove-Item -LiteralPath $file.path}
$result=[pscustomobject]@{deleted_files=$plan.Count;reclaimed_bytes=($plan | Measure-Object bytes -Sum).Sum;kept_traces=$keepTraces;kept_long_frames=@(130,131,279);original_baseline_untouched=$true;free_bytes=(Get-PSDrive C).Free}
$result | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $dest 'cleanup-summary.json') -Encoding utf8
$result | ConvertTo-Json -Depth 4

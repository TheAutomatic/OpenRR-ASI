# SPDX-License-Identifier: MIT
"""Offline FC1 tiled row/column address factorization; current retained RR baseline."""
from pathlib import Path
import difflib,hashlib,json,os,re,shutil,subprocess,sys
from collections import Counter
sys.path.insert(0,'asi/build')
from build_shaders import parse_fastmode,parse_shader_lists
from build_aco_records import fnv
from enc96_experiment_source import before_address_source

root=Path('build/aco-runtime-trace/experiment-address-screen')
control=before_address_source(root/'control-source')
source=root/'source';shutil.copytree(control,source,dirs_exist_ok=True)
patches=[]
p=source/'include/onr_block.glsl';old=p.read_text()
needle='#define WT_FC1(off) WT(off, ENC_C, HID * ENC_C)'
new=old.replace(needle,needle+chr(10)+'#define FC1_TILE(row, tile) (HID * ENC_C + (row) * ENC_C + (tile) * 256u)')
needle='#define WT_FC1(off) (off)'
new=new.replace(needle,needle+chr(10)+'#define FC1_TILE(row, tile) ((row) * ENC_C + (tile) * 16u)')
assert new!=old;p.write_text(new)
patches+=list(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='original/onr_block.glsl',tofile='fc1-address/onr_block.glsl'))
for name in ('onr_block_fast.glsl','onr_block_w2.glsl'):
 p=source/'include'/name;old=p.read_text();new=old
 # j and jt are aligned to 16 and n is an exact channel tile index.
 new=re.sub(r'WT_FC1\((j|jt) \* ENC_C \+ (\(n\)|uint\(n\)) \* 16u\)',r'FC1_TILE(\1, \2)',new)
 new=re.sub(r'WT_FC1\(\((j \+ (?:16|32|48)u)\) \* ENC_C \+ (\(n\)|uint\(n\)) \* 16u\)',r'FC1_TILE((\1), \2)',new)
 assert old!=new
 p.write_text(new)
 patches+=list(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='original/'+name,tofile='fc1-address/'+name))
(root/'source-change.patch').write_text(''.join(patches))
checks=0
for c in (32,64,96,128,160):
 for row in range(0,4*c,16):
  for tile in range(c//16):
   off=row*c+tile*16
   original=4*c*c+(off//(16*c))*16*c+((off%c)//16)*256
   direct=4*c*c+row*c+tile*256
   assert original==direct
   checks+=1
cfg=json.loads(Path('build/aco-tools/toolchain.json').read_text())
flow=parse_shader_lists('gpu')[1];lt=parse_fastmode('gpu/fastmode.cmake')
rows=[]
for name in ('enc_stage_96_128_128','enc_stage_128_128_160','dec_dfn_96_128'):
 suffix='_fl_lt';slot=flow.index(name)
 defs=['ENC_F32=1','FLOW=1',f'FLOW_SLOT={slot}',f'FLOW_WAIT={int(slot>0)}']+lt[name]
 row={'kernel':name+suffix,'numerical_expectation':'Identical byte addresses, matrix operations, K order and precision boundaries; no intended numerical change.'}
 for role,src in [('original',control),('fc1-address',source)]:
  dest=root/name/role;dest.mkdir(parents=True,exist_ok=True)
  spv=dest/(name+suffix+'.spv')
  subprocess.run(['glslangValidator','-V','--target-env','vulkan1.3',*[f'-D{d}' for d in defs],f'-I{src}/include',str(src/(name+'.comp')),'-o',str(spv)],check=True)
  if role=='original':
   expected=Path('build/aco-runtime-trace/experiment-enc96-wave-rcp/data/shaders' if name=='enc_stage_96_128_128' else 'build/asi/stage/openrr-amd/shaders')/spv.name
   assert spv.read_bytes()==expected.read_bytes(),name
  env=dict(os.environ,VK_ICD_FILENAMES=cfg['icd'],LD_PRELOAD=cfg['shim'],AMDGPU_GPU_ID='gfx1201',MESA_SHADER_CACHE_DISABLE='true',LD_LIBRARY_PATH=cfg['library_path'],ONR_ACO_PRECISION='global',ONR_ACO_VECTOR_LOADS='1',ONR_ACO_CAPTURE=str((dest/'capture').resolve()),ONR_ACO_ADDR32_HI='0x13579bdf',ONR_ISA=str(dest.resolve()))
  r=subprocess.run([str(Path('build/aco-tools/aco_capture').resolve()),str(spv.resolve())],env=env,text=True,capture_output=True)
  (dest/'compile.log').write_text(r.stdout+r.stderr);r.check_returncode()
  ir=next(dest.glob('*.2.txt')).read_text().split('After lowering to hw instructions:',1)[1]
  ops=Counter()
  for line in ir.splitlines():
   m=re.search(r'\b([sv]_[a-z0-9_]+|ds_[a-z0-9_]+|global_[a-z0-9_]+|scratch_[a-z0-9_]+)\b',line)
   if m:ops[m[1]]+=1
  row[role]={'spv_fnv':f'{fnv(spv.read_bytes()):016x}','spv_sha256':hashlib.sha256(spv.read_bytes()).hexdigest(),'resources':json.loads((dest/'capture.json').read_text()),'static_instructions':dict(sorted(ops.items()))}
 if name!='enc_stage_96_128_128':
  candidate=root/name/'candidate';data=candidate/'data/shaders';data.mkdir(parents=True,exist_ok=True)
  for p in Path('build/asi/stage/openrr-amd/shaders').glob('*.spv'):shutil.copy2(p,data/p.name)
  shutil.copy2('build/aco-runtime-trace/experiment-enc96-wave-rcp/data/shaders/enc_stage_96_128_128_fl_lt.spv',data/'enc_stage_96_128_128_fl_lt.spv')
  shutil.copy2(root/name/'fc1-address'/(name+suffix+'.spv'),data/(name+suffix+'.spv'))
  subprocess.run(['python3','asi/build/build_aco_records.py',str(data/(name+suffix+'.spv')),'--out',str(candidate/'records'),'--precision','global','--matrix-loads','vector8'],check=True)
  subprocess.run(['python3','asi/tests/merge_aco_experiment_records.py',str(candidate/'records')],check=True)
  records=candidate/'records/gfx1201/openrr-d3d12-v1'
  retained=Path('build/aco-runtime-trace/experiment-enc96-wave-rcp/records/gfx1201/openrr-d3d12-v1')
  # Both controls and candidates use current retained enc96, never the old W2 source.
  shutil.copy2(retained/'f3817f3fb0a26545.nrp',records/'f3817f3fb0a26545.nrp')
  manifest=json.loads((records/'manifest.json').read_text());base=json.loads((retained/'manifest.json').read_text())
  manifest['records']['f3817f3fb0a26545']=base['records']['f3817f3fb0a26545']
  (records/'manifest.json').write_text(json.dumps(manifest,indent=2)+chr(10))
  from build_aco_records import msgpack
  index={k:manifest[k] for k in ('schema','target','layout_version','wave_size','layout_push_bytes','mesa_commit','patch_version')}
  index['manifest_hash']=fnv((records/'manifest.json').read_bytes())
  index['records']={k:{f:r[f] for f in ('spv_hash','code_hash','workgroup','layout','record')} for k,r in manifest['records'].items()}
  (records/'manifest.msgpack').write_bytes(msgpack(index))
  row['runtime_data']=str(candidate/'data');row['runtime_records']=str(records)
 rows.append(row)
out={'factor':'FC1 tiled row/column factorization','cpu_address_checks':checks,'policy':'global/vector8','kernels':rows}
(root/'screen.json').write_text(json.dumps(out,indent=2)+chr(10))
print(json.dumps([{r['kernel']:{k:{'spv':r[k]['spv_fnv'],**r[k]['resources']} for k in ('original','fc1-address')}} for r in rows],indent=2))

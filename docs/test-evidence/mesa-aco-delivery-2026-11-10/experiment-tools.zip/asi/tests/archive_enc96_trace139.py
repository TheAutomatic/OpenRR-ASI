# SPDX-License-Identifier: MIT
"""Archive the superseded candidate's first changed DFN case and trace metadata."""
from pathlib import Path
import hashlib,json,shutil,struct
runs=Path('build/aco-runtime-trace/runs-approved-2026-11-10')
root=runs/'enc96-wave-trace-139'
out=Path('docs/test-evidence/mesa-aco-enc96-wave-tiles-experiment-2026-11-10/initial-trace139')
out.mkdir(exist_ok=True)
for p in root.iterdir():
 if p.suffix in ('.json','.csv','.log'):shutil.copy2(p,out/p.name)
 if p.is_dir():
  d=out/p.name;d.mkdir(exist_ok=True)
  for name in ('trace.txt','aco-manifest.json'):shutil.copy2(p/name,d/name)
shutil.copy2(runs/'enc96-wave-trace139-diff.json',out/'diff.json')
rows=[]
for p in sorted((root/'baseline-trace-139').glob('*.bin')):
 q=root/'candidate-trace-139'/p.name
 a=p.read_bytes();b=q.read_bytes()
 row={'file':p.name,'original_sha256':hashlib.sha256(a).hexdigest(),'candidate_sha256':hashlib.sha256(b).hexdigest(),'equal':a==b}
 if p.name=='6-enc_stage_96_128_128_fl_lt-dfn.bin':
  row['first_case']={'halfword':4121,'original_bits':hex(struct.unpack_from('<H',a,8242)[0]),'candidate_bits':hex(struct.unpack_from('<H',b,8242)[0])}
 rows.append(row)
for label in ('baseline','candidate'):
 a=root/f'{label}-trace-139/output.bin';b=runs/'enc96-wave-long-correctness'/f'{label}-steady-131.bin'
 assert a.read_bytes()==b.read_bytes()
(out/'readback-hashes.json').write_text(json.dumps({'traced_untraced_equal':True,'readbacks':rows},indent=2)+chr(10))
print('Archived initial frame139 case, 69 readbacks per side')

# SPDX-License-Identifier: MIT
"""Archive offline address-screen hashes, source patch, IR and selected records."""
from pathlib import Path
import hashlib,json,shutil,zipfile
root=Path('build/aco-runtime-trace/experiment-address-screen')
out=Path('docs/test-evidence/mesa-aco-address-screen-2026-11-10');out.mkdir(exist_ok=True)
screen=json.loads((root/'screen.json').read_text())
files=[]
for row in screen['kernels']:
 name=row['kernel'].removesuffix('_fl_lt')
 for role in ('original','fc1-address'):
  d=root/name/role
  files += [p for p in d.iterdir() if p.is_file()]
  row[role]['code_sha256']=hashlib.sha256((d/'capture.code').read_bytes()).hexdigest()
 if 'runtime_records' in row:
  records=Path(row['runtime_records']);manifest=json.loads((records/'manifest.json').read_text())
  key=row['fc1-address']['spv_fnv'];row['fc1-address']['record']=manifest['records'][key]
  files += [records/(key+'.nrp')]
  shutil.copy2(records/'manifest.json',out/(name+'-manifest.json'))
  original=Path('build/aco-runtime-trace/experiment-enc96-wave-rcp/data/shaders')
  candidate=Path(row['runtime_data'])/'shaders'
  assert {p.name for p in original.glob('*.spv')}=={p.name for p in candidate.glob('*.spv')}
  changed=[p.name for p in original.glob('*.spv') if p.read_bytes()!=(candidate/p.name).read_bytes()]
  assert changed==[row['kernel']+'.spv'],changed
  row['changed_shaders_vs_current_retained']=changed
 rows=[]
 for op in sorted(set(row['original']['static_instructions'])|set(row['fc1-address']['static_instructions'])):
  a=row['original']['static_instructions'].get(op,0);b=row['fc1-address']['static_instructions'].get(op,0)
  if a!=b:rows.append({'opcode':op,'original':a,'candidate':b})
 row['instruction_changes']=rows
 files += [root/'source-change.patch'] if not files else []
archive=out/'compiler-evidence.zip';members=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(files+[root/'source-change.patch'])):
  name=p.relative_to(root).as_posix();data=p.read_bytes();z.writestr(name,data)
  members.append({'file':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for m in members:assert hashlib.sha256(z.read(m['file'])).hexdigest()==m['sha256']
(out/'screen.json').write_text(json.dumps(screen,indent=2)+chr(10))
(out/'archive.json').write_text(json.dumps({'file':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':members},indent=2)+chr(10))
shutil.copy2(root/'source-change.patch',out/'source-change.patch')
print(json.dumps({'archive_bytes':archive.stat().st_size,'address_checks':screen['cpu_address_checks'],'records_ready':[r.get('runtime_records') for r in screen['kernels'] if 'runtime_records' in r]},indent=2))

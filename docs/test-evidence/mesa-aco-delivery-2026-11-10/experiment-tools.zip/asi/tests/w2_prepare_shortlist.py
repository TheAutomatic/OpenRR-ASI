# SPDX-License-Identifier: MIT
"""Make two isolated short-test candidates atop the retained enc96 baseline."""
from pathlib import Path
import json,shutil,subprocess,sys
sys.path.insert(0,'asi/build')
from build_aco_records import fnv,msgpack
root=Path('build/aco-runtime-trace/experiment-w2-screen')
base=Path('build/asi/stage/openrr-amd/shaders')
enc=Path('build/aco-runtime-trace/experiment-enc96-wave-rcp')
names=['dec_dfn_64_64_f_lt','dec_up_64_64_96_f_lt']
for kernel in names:
 name=kernel.removesuffix('_f_lt');out=root/'shortlist'/name
 data=out/'data/shaders';data.mkdir(parents=True,exist_ok=True)
 for p in base.glob('*.spv'):shutil.copy2(p,data/p.name)
 shutil.copy2(enc/'data/shaders/enc_stage_96_128_128_fl_lt.spv',data/'enc_stage_96_128_128_fl_lt.spv')
 spv=root/name/'single-tile'/(kernel+'.spv');shutil.copy2(spv,data/spv.name)
 subprocess.run([sys.executable,'asi/build/build_aco_records.py',str(spv),'--out',str(out/'records'),'--precision','global','--matrix-loads','vector8'],check=True)
 dest=out/'records/gfx1201/openrr-d3d12-v1';m=json.loads((dest/'manifest.json').read_text())
 baseline=enc/'records/gfx1201/openrr-d3d12-v1';bm=json.loads((baseline/'manifest.json').read_text())
 assert m['compile_options']==bm['compile_options']
 for p in baseline.glob('*.nrp'):shutil.copy2(p,dest/p.name)
 bm['records'].update(m['records']);bm['experiment']=str(out)
 manifest=dest/'manifest.json';manifest.write_text(json.dumps(bm,indent=2)+chr(10))
 index={k:bm[k] for k in ('schema','target','layout_version','wave_size','layout_push_bytes','mesa_commit','patch_version')}
 index['manifest_hash']=fnv(manifest.read_bytes());index['records']={k:{f:r[f] for f in ('spv_hash','code_hash','workgroup','layout','record')} for k,r in bm['records'].items()}
 (dest/'manifest.msgpack').write_bytes(msgpack(index))
 # Original and candidate directories share enc96 and differ in just this kernel.
 original=out/'original/shaders';original.mkdir(parents=True,exist_ok=True)
 for p in data.glob('*.spv'):shutil.copy2(p,original/p.name)
 shutil.copy2(base/spv.name,original/spv.name)
 changed=[p.name for p in original.glob('*.spv') if p.read_bytes()!=(data/p.name).read_bytes()]
 assert changed==[spv.name],changed
 print(json.dumps({'kernel':kernel,'candidate_spv':f'{fnv(spv.read_bytes()):016x}','original_data':str(original.parent),'candidate_data':str(data.parent),'records':str(dest),'changed':changed}))

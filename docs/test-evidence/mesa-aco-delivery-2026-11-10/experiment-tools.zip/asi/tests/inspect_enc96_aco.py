# SPDX-License-Identifier: MIT
"""Capture enc96 compiler IR offline; verify against its saved ACO code body."""
from pathlib import Path
import os,json,subprocess,sys
root=Path('build/aco-runtime-trace/experiment-enc96')
label=sys.argv[1] if len(sys.argv)>1 else 'original'
spv=Path(sys.argv[2]) if len(sys.argv)>2 else Path('build/asi/stage/openrr-amd/shaders/enc_stage_96_128_128_fl_lt.spv')
expected=Path(sys.argv[3]) if len(sys.argv)>3 else Path('build/aco-review-v4/global-vector8/gfx1201/openrr-d3d12-v1/capture/581ef3189b0a0052-a.code')
out=(root/'ir'/label).resolve();out.mkdir(parents=True,exist_ok=True)
cfg=json.loads(Path('build/aco-tools/toolchain.json').read_text())
env=dict(os.environ,VK_ICD_FILENAMES=cfg['icd'],LD_PRELOAD=cfg['shim'],
 AMDGPU_GPU_ID='gfx1201',MESA_SHADER_CACHE_DISABLE='true',LD_LIBRARY_PATH=cfg['library_path'],
 ONR_ACO_PRECISION='global',ONR_ACO_VECTOR_LOADS='1',ONR_ACO_CAPTURE=str(out/'capture'),
 ONR_ACO_ADDR32_HI='0x13579bdf',ONR_ISA=str(out))
r=subprocess.run([str(Path('build/aco-tools/aco_capture').resolve()),str(spv.resolve())],env=env,text=True,capture_output=True)
(out/'compile.log').write_text(r.stdout+r.stderr);r.check_returncode()
assert (out/'capture.code').read_bytes()==expected.read_bytes(),'capture body differs from saved record'
print((out/'capture.json').read_text())

# SPDX-License-Identifier: MIT
"""Isolate enc96 merge LDS address strength reduction; no arithmetic changes."""
from pathlib import Path
import shutil,subprocess,sys,json,difflib
sys.path.insert(0,'asi/build')
from build_shaders import parse_shader_lists,parse_fastmode
from build_aco_records import fnv
from enc96_experiment_source import baseline_shader
root=Path('build/aco-runtime-trace/experiment-enc96');source=root/'source'
shutil.copytree('gpu/shaders',source,dirs_exist_ok=True)
baseline_shader(root,source)
p=source/'include/onr_block_w2.glsl';s=p.read_text()
old=r'''#define MST(xn, t0, n) { MH h_ = xn; uint t_ = (t0) + (ln & 15u); \
        uint a_ = ((t_ >> 4) * 4u + ((t_ & 7u) >> 1)) * 4u * ENC_C + ((((t_ >> 3) & 1u) << 1) + (t_ & 1u)) * ENC_C + (n) * 16u + 8u * hh; \
        lds4[a_ >> 3] ='''.replace('\n+','\n')
new=r'''#define MST(xn, t0, n) { MH h_ = xn; \
        uint row_ = ((t0) >> 4) * 4u + ((ln >> 1) & 3u); \
        uint sub_ = ((ln >> 2) & 2u) | (ln & 1u); \
        uint idx_ = row_ * (ENC_C / 2u) + sub_ * (ENC_C / 8u) + (n) * 2u + hh; \
        lds4[idx_] ='''.replace('\n+','\n')
assert s.count(old)==1,repr(old)
p.write_text(s.replace(old,new))
# Exhaustive integer equivalence for the supported W2 lane/token mapping.
for w in range(2):
 for lane in range(32):
  for tile in range(2):
   for n in range(6):
    t0=32*w+16*tile;t=t0+(lane&15);hh=lane>>4
    a=(((t>>4)*4+((t&7)>>1))*4*96+((((t>>3)&1)<<1)+(t&1))*96+n*16+8*hh)>>3
    b=((t0>>4)*4+((lane>>1)&3))*48+(((lane>>2)&2)|(lane&1))*12+n*2+hh
    assert a==b
name='enc_stage_96_128_128';flow=parse_shader_lists('gpu')[1];slot=flow.index(name)
defs=['ENC_F32=1','FLOW=1',f'FLOW_SLOT={slot}',f'FLOW_WAIT={int(slot>0)}']+parse_fastmode('gpu/fastmode.cmake')[name]
spvname=name+'_fl_lt.spv';base=root/'reference';base.mkdir(exist_ok=True)
data=root/'data/shaders';data.mkdir(parents=True,exist_ok=True)
for f in Path('build/asi/stage/openrr-amd/shaders').glob('*.spv'):shutil.copy2(f,data/f.name)
for inc,src,dst in [('gpu/shaders/include',base,base/spvname),(str(source/'include'),source,data/spvname)]:
 subprocess.run(['glslangValidator','-V','--target-env','vulkan1.3',*[f'-D{d}' for d in defs],f'-I{inc}',str(src/(name+'.comp')),'-o',str(dst)],check=True)
baseline=Path('build/asi/stage/openrr-amd/shaders')/spvname
assert (base/spvname).read_bytes()==baseline.read_bytes()
(root/'source-change.patch').write_text(''.join(difflib.unified_diff(s.splitlines(True),s.replace(old,new).splitlines(True),fromfile='original/onr_block_w2.glsl',tofile='candidate/onr_block_w2.glsl')))
print(json.dumps({'baseline_spv':f'{fnv(baseline.read_bytes()):016x}','candidate_spv':f'{fnv((data/spvname).read_bytes()):016x}','defines':defs},indent=2))

# SPDX-License-Identifier: MIT
from pathlib import Path
import sys,json,shutil,subprocess,os
sys.path.insert(0,'asi/build')
from build_aco_records import fnv,msgpack
root=Path('build/aco-runtime-trace/experiment-enc128-unroll')
base=Path('build/aco-runtime-trace/experiment-cmat-address/dec_dfn_96_128_fl_lt/candidate')
dest=root/'candidate';shutil.copytree(base/'data/shaders',dest/'data/shaders',dirs_exist_ok=True)
spv=root/'enc_stage_128_128_160_fl_lt.spv';shutil.copy2(spv,dest/'data/shaders'/spv.name)
env=dict(os.environ,ONR_ACO_CMAT_ADDRESS='1')
subprocess.run([sys.executable,'asi/build/build_aco_records.py',str(spv),'--out',str(dest/'records'),'--toolchain','build/aco-runtime-trace/experiment-cmat-address/isolated-toolchain.json','--precision','global','--matrix-loads','vector8','--cmat-address-shaders',spv.stem],env=env,check=True)
r=dest/'records/gfx1201/openrr-d3d12-v1';m=json.loads((r/'manifest.json').read_text());b=base/'records/gfx1201/openrr-d3d12-v1';bm=json.loads((b/'manifest.json').read_text())
for p in b.glob('*.nrp'):shutil.copy2(p,r/p.name)
bm['records'].update(m['records']);bm['experiment']='enc128 one MLP loop DontUnroll + cmat bounded lane address; retained dec96 cmat address on both sides'
manifest=r/'manifest.json';manifest.write_text(json.dumps(bm,indent=2)+chr(10))
index={k:bm[k] for k in ('schema','target','layout_version','wave_size','layout_push_bytes','mesa_commit','patch_version')};index['manifest_hash']=fnv(manifest.read_bytes());index['records']={k:{f:v[f] for f in ('spv_hash','code_hash','workgroup','layout','record')} for k,v in bm['records'].items()}
(r/'manifest.msgpack').write_bytes(msgpack(index));shutil.copytree(dest/'records',dest/'data/aco',dirs_exist_ok=True)
print(f'{fnv(spv.read_bytes()):016x}',m['records'])
